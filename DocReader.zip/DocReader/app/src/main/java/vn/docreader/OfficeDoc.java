package vn.docreader;

import android.util.Xml;

import org.xmlpull.v1.XmlPullParser;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.MathContext;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Đọc DOCX / XLSX / PPTX (các file zip chứa XML) và chuyển thành HTML để hiển thị. Không cần thư viện ngoài. */
abstract class OfficeDoc {
    ZipFile zip;

    abstract int count();

    abstract String sectionTitle(int i);

    abstract String html(int i, String css) throws Exception;

    void init() throws Exception { }

    void close() {
        try {
            if (zip != null) zip.close();
        } catch (Exception ignored) { }
    }

    /** Nhận dạng loại file zip: docx, xlsx, pptx, epub hoặc null. */
    static String kindOf(ZipFile z) {
        if (z.getEntry("word/document.xml") != null) return "docx";
        if (z.getEntry("xl/workbook.xml") != null) return "xlsx";
        if (z.getEntry("ppt/presentation.xml") != null) return "pptx";
        if (z.getEntry("META-INF/container.xml") != null) return "epub";
        return null;
    }

    static OfficeDoc open(File f, String kind) throws Exception {
        ZipFile z = new ZipFile(f);
        try {
            OfficeDoc d;
            if (kind.equals("docx")) d = new Docx();
            else if (kind.equals("xlsx")) d = new Xlsx();
            else d = new Pptx();
            d.zip = z;
            d.init();
            return d;
        } catch (Exception e) {
            try {
                z.close();
            } catch (Exception ignored) { }
            throw e;
        }
    }

    // ------------------------------------------------------------ tiện ích

    static XmlPullParser parser(InputStream in) throws Exception {
        XmlPullParser p = Xml.newPullParser();
        p.setInput(in, null);
        return p;
    }

    static InputStream stream(ZipFile z, String path) throws Exception {
        ZipEntry e = z.getEntry(path);
        return e == null ? null : z.getInputStream(e);
    }

    static byte[] readEntry(ZipFile z, String path) throws Exception {
        ZipEntry e = z.getEntry(path);
        if (e == null) return null;
        try (InputStream in = z.getInputStream(e)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toByteArray();
        }
    }

    static String esc(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    /** Tên thẻ không kèm tiền tố (w:p -> p) để đọc được file do nhiều phần mềm khác nhau tạo ra. */
    static String nm(XmlPullParser p) {
        String n = p.getName();
        int i = n.indexOf(':');
        return i < 0 ? n : n.substring(i + 1);
    }

    static String attr(XmlPullParser p, String name) {
        String v = p.getAttributeValue(null, name);
        if (v != null) return v;
        for (int i = 0; i < p.getAttributeCount(); i++) {
            String an = p.getAttributeName(i);
            int c = an.indexOf(':');
            if (name.indexOf(':') >= 0 && c < 0) continue; // tên có tiền tố thì chỉ khớp thuộc tính có tiền tố
            if (name.indexOf(':') >= 0) name = name.substring(name.indexOf(':') + 1);
            if ((c < 0 ? an : an.substring(c + 1)).equals(name)) return p.getAttributeValue(i);
        }
        return null;
    }

    static boolean on(XmlPullParser p) {
        String v = attr(p, "val");
        return !("0".equals(v) || "false".equals(v) || "off".equals(v) || "none".equals(v));
    }

    static int toInt(String s, int def) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Exception e) {
            return def;
        }
    }

    /** Bỏ qua toàn bộ phần tử con đang mở. */
    static void skip(XmlPullParser p) throws Exception {
        int depth = 1;
        while (depth > 0) {
            int e = p.next();
            if (e == XmlPullParser.START_TAG) depth++;
            else if (e == XmlPullParser.END_TAG) depth--;
            else if (e == XmlPullParser.END_DOCUMENT) break;
        }
    }

    static Map<String, String> rels(ZipFile z, String relsPath, String baseDir) throws Exception {
        Map<String, String> m = new HashMap<>();
        InputStream in = stream(z, relsPath);
        if (in == null) return m;
        try {
            XmlPullParser p = parser(in);
            for (int e = p.getEventType(); e != XmlPullParser.END_DOCUMENT; e = p.next()) {
                if (e == XmlPullParser.START_TAG && nm(p).equals("Relationship")) {
                    String id = attr(p, "Id");
                    String t = attr(p, "Target");
                    String mode = attr(p, "TargetMode");
                    if (id != null && t != null && !"External".equals(mode)) {
                        m.put(id, EpubBook.resolve(baseDir, t));
                    }
                }
            }
        } finally {
            in.close();
        }
        return m;
    }

    static String page(String css, String body) {
        return "<html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><style>"
                + css
                + "p{margin:0 0 .6em}table{border-collapse:collapse;margin:8px 0}"
                + "td,th{border:1px solid #999;padding:4px 6px;vertical-align:top}"
                + "td.n{text-align:right}td.rn,th{background:rgba(128,128,128,.18);font-size:80%;text-align:center}"
                + "</style></head><body>" + body + "</body></html>";
    }

    static String fmt(String t, boolean b, boolean i, boolean u, boolean s) {
        if (t.isEmpty()) return t;
        if (b) t = "<b>" + t + "</b>";
        if (i) t = "<i>" + t + "</i>";
        if (u) t = "<u>" + t + "</u>";
        if (s) t = "<s>" + t + "</s>";
        return t;
    }

    static String img(String path) {
        return "<img src=\"https://epub.local/" + android.net.Uri.encode(path, "/") + "\">";
    }

    // ------------------------------------------------------------ DOCX

    static class Docx extends OfficeDoc {
        @Override int count() { return 1; }

        @Override String sectionTitle(int i) { return "Văn bản"; }

        @Override
        String html(int idx, String css) throws Exception {
            Map<String, String> rels = rels(zip, "word/_rels/document.xml.rels", "word/");
            StringBuilder sb = new StringBuilder();
            StringBuilder para = new StringBuilder();
            boolean b = false, i = false, u = false, s = false, list = false;
            int heading = 0, level = 0;
            String align = null;
            ArrayDeque<Integer> tdStack = new ArrayDeque<>();
            java.util.LinkedHashSet<String> seen = new java.util.LinkedHashSet<>();

            InputStream in = stream(zip, "word/document.xml");
            if (in == null) throw new Exception("Thiếu word/document.xml");
            try {
                XmlPullParser p = parser(in);
                for (int e = p.getEventType(); e != XmlPullParser.END_DOCUMENT; e = p.next()) {
                    if (e == XmlPullParser.START_TAG) {
                        String n = nm(p);
                        if (seen.size() < 12) seen.add(n);
                        switch (n) {
                            case "Fallback":
                            case "txbxContent":
                                skip(p);
                                break;
                            case "p":
                                para.setLength(0);
                                heading = 0;
                                level = 0;
                                align = null;
                                list = false;
                                break;
                            case "pStyle": {
                                String v = attr(p, "val");
                                if (v != null) {
                                    String lo = v.toLowerCase(Locale.ROOT);
                                    if (lo.startsWith("heading") && lo.length() > 7) heading = toInt(lo.substring(7), 2);
                                    else if (lo.equals("title")) heading = 1;
                                    else if (lo.equals("subtitle")) heading = 2;
                                }
                                break;
                            }
                            case "jc": {
                                String v = attr(p, "val");
                                if ("center".equals(v)) align = "center";
                                else if ("right".equals(v) || "end".equals(v)) align = "right";
                                else if ("both".equals(v)) align = "justify";
                                break;
                            }
                            case "numPr":
                                list = true;
                                break;
                            case "ilvl":
                                level = toInt(attr(p, "val"), 0);
                                break;
                            case "numId":
                                if ("0".equals(attr(p, "val"))) list = false;
                                break;
                            case "r":
                                b = false;
                                i = false;
                                u = false;
                                s = false;
                                break;
                            case "b":
                                b = on(p);
                                break;
                            case "i":
                                i = on(p);
                                break;
                            case "u":
                                u = on(p);
                                break;
                            case "strike":
                                s = on(p);
                                break;
                            case "t":
                                para.append(fmt(esc(p.nextText()), b, i, u, s));
                                break;
                            case "tab":
                                para.append("&emsp;");
                                break;
                            case "br":
                                para.append("page".equals(attr(p, "type")) ? "<hr>" : "<br>");
                                break;
                            case "blip": {
                                String path = rels.get(attr(p, "r:embed"));
                                if (path != null) para.append(img(path));
                                break;
                            }
                            case "imagedata": {
                                String path = rels.get(attr(p, "r:id"));
                                if (path != null) para.append(img(path));
                                break;
                            }
                            case "tbl":
                                sb.append("<table>");
                                break;
                            case "tr":
                                sb.append("<tr>");
                                break;
                            case "tc":
                                sb.append("<td>");
                                tdStack.push(sb.length() - 1);
                                break;
                            case "gridSpan":
                                if (!tdStack.isEmpty()) {
                                    sb.insert(tdStack.peek(), " colspan=\"" + toInt(attr(p, "val"), 1) + "\"");
                                }
                                break;
                            default:
                                break;
                        }
                    } else if (e == XmlPullParser.END_TAG) {
                        String n = nm(p);
                        if (n.equals("p")) {
                            String text = para.toString();
                            String tag = heading > 0 ? "h" + Math.min(heading, 6) : "p";
                            StringBuilder st = new StringBuilder();
                            if (align != null) st.append("text-align:").append(align).append(";");
                            if (list) st.append("margin-left:").append(18 + level * 18).append("px;");
                            sb.append("<").append(tag);
                            if (st.length() > 0) sb.append(" style=\"").append(st).append("\"");
                            sb.append(">");
                            if (list) sb.append("• ");
                            sb.append(text.isEmpty() ? "&nbsp;" : text);
                            sb.append("</").append(tag).append(">");
                        } else if (n.equals("tc")) {
                            sb.append("</td>");
                            if (!tdStack.isEmpty()) tdStack.pop();
                        } else if (n.equals("tr")) {
                            sb.append("</tr>");
                        } else if (n.equals("tbl")) {
                            sb.append("</table>");
                        }
                    }
                }
            } finally {
                in.close();
            }
            String out = sb.toString();
            if (out.replaceAll("<[^>]*>", "").replace("&nbsp;", "").trim().isEmpty() && !out.contains("<img")) {
                out = "<p>Không thấy nội dung văn bản trong file này.</p><p style=\"font-size:70%;color:gray\">Thẻ gặp: " + esc(seen.toString()) + "</p>";
            }
            return page(css, out);
        }
    }

    // ------------------------------------------------------------ XLSX

    static class Xlsx extends OfficeDoc {
        static final int MAX_ROWS = 5000;
        static final int MAX_COLS = 100;

        final List<String> names = new ArrayList<>();
        final List<String> paths = new ArrayList<>();
        final List<String> shared = new ArrayList<>();
        final Map<Integer, String> numFmts = new HashMap<>();
        final List<Integer> xfFmt = new ArrayList<>();
        boolean date1904;

        @Override int count() { return names.size(); }

        @Override String sectionTitle(int i) { return names.get(i); }

        @Override
        void init() throws Exception {
            Map<String, String> rels = rels(zip, "xl/_rels/workbook.xml.rels", "xl/");
            InputStream in = stream(zip, "xl/workbook.xml");
            if (in == null) throw new Exception("Thiếu xl/workbook.xml");
            try {
                XmlPullParser p = parser(in);
                for (int e = p.getEventType(); e != XmlPullParser.END_DOCUMENT; e = p.next()) {
                    if (e != XmlPullParser.START_TAG) continue;
                    String n = nm(p);
                    if (n.equals("workbookPr")) {
                        String d = attr(p, "date1904");
                        date1904 = "1".equals(d) || "true".equals(d);
                    } else if (n.equals("sheet")) {
                        String path = rels.get(attr(p, "r:id"));
                        if (path != null) {
                            String nm = attr(p, "name");
                            names.add(nm == null ? "Sheet" + (names.size() + 1) : nm);
                            paths.add(path);
                        }
                    }
                }
            } finally {
                in.close();
            }
            if (names.isEmpty()) {
                // Một số phần mềm ghi file khác chuẩn: tự tìm các sheet trong file nén
                List<String> found = new ArrayList<>();
                java.util.Enumeration<? extends ZipEntry> en = zip.entries();
                while (en.hasMoreElements()) {
                    String n = en.nextElement().getName();
                    if (n.startsWith("xl/worksheets/") && n.endsWith(".xml") && n.indexOf('/', 14) < 0) found.add(n);
                }
                java.util.Collections.sort(found, (x, y) -> {
                    int a1 = toInt(x.replaceAll("\\D", ""), 0), b1 = toInt(y.replaceAll("\\D", ""), 0);
                    return a1 != b1 ? Integer.compare(a1, b1) : x.compareTo(y);
                });
                for (String f : found) {
                    paths.add(f);
                    names.add("Sheet " + (names.size() + 1));
                }
            }
            if (names.isEmpty()) throw new Exception("Bảng tính không có sheet");

            in = stream(zip, "xl/sharedStrings.xml");
            if (in != null) {
                try {
                    XmlPullParser p = parser(in);
                    StringBuilder cur = new StringBuilder();
                    boolean inSi = false;
                    for (int e = p.getEventType(); e != XmlPullParser.END_DOCUMENT; e = p.next()) {
                        if (e == XmlPullParser.START_TAG) {
                            String n = nm(p);
                            if (n.equals("si")) {
                                cur.setLength(0);
                                inSi = true;
                            } else if (n.equals("rPh")) {
                                skip(p);
                            } else if (n.equals("t") && inSi) {
                                cur.append(p.nextText());
                            }
                        } else if (e == XmlPullParser.END_TAG && nm(p).equals("si")) {
                            shared.add(cur.toString());
                            inSi = false;
                        }
                    }
                } finally {
                    in.close();
                }
            }

            in = stream(zip, "xl/styles.xml");
            if (in != null) {
                try {
                    XmlPullParser p = parser(in);
                    boolean inXfs = false;
                    for (int e = p.getEventType(); e != XmlPullParser.END_DOCUMENT; e = p.next()) {
                        if (e == XmlPullParser.START_TAG) {
                            String n = nm(p);
                            if (n.equals("numFmt")) {
                                String code = attr(p, "formatCode");
                                if (code != null) numFmts.put(toInt(attr(p, "numFmtId"), -1), code);
                            } else if (n.equals("cellXfs")) {
                                inXfs = true;
                            } else if (n.equals("xf") && inXfs) {
                                xfFmt.add(toInt(attr(p, "numFmtId"), 0));
                            }
                        } else if (e == XmlPullParser.END_TAG && nm(p).equals("cellXfs")) {
                            inXfs = false;
                        }
                    }
                } finally {
                    in.close();
                }
            }
        }

        static long key(int row, int col) {
            return row * 100000L + col;
        }

        static int[] cellRef(String ref) {
            int i = 0, col = 0;
            while (i < ref.length() && Character.isLetter(ref.charAt(i))) {
                col = col * 26 + (Character.toUpperCase(ref.charAt(i)) - 'A' + 1);
                i++;
            }
            return new int[]{col, toInt(ref.substring(i), 0)};
        }

        static String colName(int c) {
            StringBuilder sb = new StringBuilder();
            while (c > 0) {
                int r = (c - 1) % 26;
                sb.insert(0, (char) ('A' + r));
                c = (c - 1) / 26;
            }
            return sb.toString();
        }

        @Override
        String html(int idx, String css) throws Exception {
            String path = paths.get(idx);
            Map<Long, int[]> merges = new HashMap<>();
            Set<Long> covered = new HashSet<>();
            int maxCol = 0;

            InputStream in1 = stream(zip, path);
            if (in1 == null) throw new Exception("Thiếu " + path);
            try {
                XmlPullParser p = parser(in1);
                for (int e = p.getEventType(); e != XmlPullParser.END_DOCUMENT; e = p.next()) {
                    if (e != XmlPullParser.START_TAG) continue;
                    String n = nm(p);
                    if (n.equals("mergeCell")) {
                        String ref = attr(p, "ref");
                        if (ref != null && ref.contains(":")) {
                            String[] ab = ref.split(":");
                            int[] a = cellRef(ab[0]);
                            int[] bb = cellRef(ab[1]);
                            if (a[0] > 0 && a[1] > 0 && bb[0] >= a[0] && bb[1] >= a[1]
                                    && (long) (bb[0] - a[0] + 1) * (bb[1] - a[1] + 1) <= 100000L) {
                                merges.put(key(a[1], a[0]), new int[]{bb[1] - a[1] + 1, bb[0] - a[0] + 1});
                                for (int r = a[1]; r <= bb[1]; r++) {
                                    for (int c = a[0]; c <= bb[0]; c++) {
                                        if (r != a[1] || c != a[0]) covered.add(key(r, c));
                                    }
                                }
                            }
                        }
                    } else if (n.equals("dimension")) {
                        String ref = attr(p, "ref");
                        if (ref != null) {
                            String[] ab = ref.split(":");
                            maxCol = cellRef(ab[ab.length - 1])[0];
                        }
                    }
                }
            } finally {
                in1.close();
            }

            StringBuilder sb = new StringBuilder("<table>");
            if (maxCol > 0) {
                sb.append("<tr><th></th>");
                for (int c = 1; c <= Math.min(maxCol, MAX_COLS); c++) sb.append("<th>").append(colName(c)).append("</th>");
                sb.append("</tr>");
            }

            boolean truncated = false, inRow = false, inCell = false, inIs = false;
            int rows = 0, curRow = 0, curCol = 0, lastCol = 0;
            String curType = null, curStyle = null, curVal = null;
            StringBuilder isb = new StringBuilder();

            InputStream in = stream(zip, path);
            try {
                XmlPullParser p = parser(in);
                loop:
                for (int e = p.getEventType(); e != XmlPullParser.END_DOCUMENT; e = p.next()) {
                    if (e == XmlPullParser.START_TAG) {
                        String n = nm(p);
                        switch (n) {
                            case "row":
                                if (inRow) sb.append("</tr>");
                                curRow = toInt(attr(p, "r"), curRow + 1);
                                rows++;
                                if (rows > MAX_ROWS) {
                                    truncated = true;
                                    inRow = false;
                                    break loop;
                                }
                                sb.append("<tr><td class=\"rn\">").append(curRow).append("</td>");
                                lastCol = 0;
                                inRow = true;
                                break;
                            case "c": {
                                String ref = attr(p, "r");
                                curCol = ref != null ? cellRef(ref)[0] : lastCol + 1;
                                curType = attr(p, "t");
                                curStyle = attr(p, "s");
                                curVal = null;
                                inCell = true;
                                break;
                            }
                            case "v":
                                if (inCell) curVal = p.nextText();
                                break;
                            case "is":
                                inIs = true;
                                isb.setLength(0);
                                break;
                            case "rPh":
                                if (inIs) skip(p);
                                break;
                            case "t":
                                if (inIs) isb.append(p.nextText());
                                break;
                            default:
                                break;
                        }
                    } else if (e == XmlPullParser.END_TAG) {
                        String n = nm(p);
                        if (n.equals("is")) {
                            inIs = false;
                            curVal = isb.toString();
                            curType = "inlineStr";
                        } else if (n.equals("c")) {
                            inCell = false;
                            if (curCol > MAX_COLS) {
                                lastCol = curCol;
                            } else {
                                for (int c = lastCol + 1; c < curCol && c <= MAX_COLS; c++) {
                                    if (!covered.contains(key(curRow, c))) sb.append("<td></td>");
                                }
                                lastCol = curCol;
                                if (!covered.contains(key(curRow, curCol))) {
                                    boolean num = false;
                                    String text;
                                    String v = curVal;
                                    if (v == null) {
                                        text = "";
                                    } else if ("s".equals(curType)) {
                                        int k = toInt(v, -1);
                                        text = (k >= 0 && k < shared.size()) ? esc(shared.get(k)) : "";
                                    } else if ("b".equals(curType)) {
                                        text = "1".equals(v) ? "TRUE" : "FALSE";
                                    } else if ("str".equals(curType) || "inlineStr".equals(curType) || "e".equals(curType)) {
                                        text = esc(v);
                                    } else {
                                        num = true;
                                        text = esc(formatNum(v, curStyle));
                                    }
                                    text = text.replace("\n", "<br>");
                                    int[] m = merges.get(key(curRow, curCol));
                                    sb.append("<td");
                                    if (m != null) {
                                        if (m[0] > 1) sb.append(" rowspan=\"").append(m[0]).append("\"");
                                        if (m[1] > 1) sb.append(" colspan=\"").append(m[1]).append("\"");
                                    }
                                    if (num) sb.append(" class=\"n\"");
                                    sb.append(">").append(text).append("</td>");
                                }
                            }
                        } else if (n.equals("row")) {
                            if (inRow) sb.append("</tr>");
                            inRow = false;
                        }
                    }
                }
            } finally {
                if (in != null) in.close();
            }
            if (inRow) sb.append("</tr>");
            sb.append("</table>");
            if (truncated) {
                sb.append("<p><i>Chỉ hiển thị ").append(MAX_ROWS).append(" dòng đầu của sheet này.</i></p>");
            }
            return page(css, sb.toString());
        }

        // ---- định dạng số / ngày

        static boolean builtinDate(int id) {
            return (id >= 14 && id <= 22) || (id >= 27 && id <= 36) || (id >= 45 && id <= 47) || (id >= 50 && id <= 58);
        }

        boolean isDateFmt(int id) {
            if (builtinDate(id)) return true;
            String code = numFmts.get(id);
            if (code == null) return false;
            String c = code.replaceAll("\"[^\"]*\"", "").replaceAll("\\[[^\\]]*\\]", "")
                    .replaceAll("\\\\.", "").toLowerCase(Locale.ROOT);
            int semi = c.indexOf(';');
            if (semi >= 0) c = c.substring(0, semi);
            return c.matches(".*[ymdhs].*");
        }

        static int decimalsOf(String code) {
            if (code == null) return 0;
            String c = code.replaceAll("\"[^\"]*\"", "");
            int semi = c.indexOf(';');
            if (semi >= 0) c = c.substring(0, semi);
            int dot = c.indexOf('.');
            if (dot < 0) return 0;
            int n = 0;
            for (int i = dot + 1; i < c.length(); i++) {
                char ch = c.charAt(i);
                if (ch == '0' || ch == '#') n++;
                else break;
            }
            return n;
        }

        static String pattern(boolean group, int dec) {
            StringBuilder sb = new StringBuilder(group ? "#,##0" : "0");
            if (dec > 0) {
                sb.append('.');
                for (int i = 0; i < dec; i++) sb.append('0');
            }
            return sb.toString();
        }

        String formatNum(String v, String style) {
            int fid = 0;
            if (style != null) {
                int si = toInt(style, -1);
                if (si >= 0 && si < xfFmt.size()) fid = xfFmt.get(si);
            }
            try {
                double d = Double.parseDouble(v);
                if (isDateFmt(fid)) return dateStr(d);
                String code = numFmts.get(fid);
                DecimalFormatSymbols sym = DecimalFormatSymbols.getInstance(Locale.US);
                if (fid == 9 || fid == 10 || (code != null && code.contains("%"))) {
                    int dec = fid == 9 ? 0 : fid == 10 ? 2 : decimalsOf(code);
                    return new DecimalFormat(pattern(false, dec), sym).format(d * 100) + "%";
                }
                if (fid == 3 || fid == 4 || (fid >= 37 && fid <= 40) || (code != null && code.contains("#,##0"))) {
                    int dec = (fid == 4 || fid == 39 || fid == 40) ? 2 : (code != null ? decimalsOf(code) : 0);
                    return new DecimalFormat(pattern(true, dec), sym).format(d);
                }
                if (fid == 1) return new DecimalFormat("0", sym).format(d);
                if (fid == 2) return new DecimalFormat("0.00", sym).format(d);
                if (d == Math.rint(d) && Math.abs(d) < 1e15) return String.valueOf((long) d);
                return new BigDecimal(v).round(new MathContext(12)).stripTrailingZeros().toPlainString();
            } catch (NumberFormatException ex) {
                return v;
            }
        }

        String dateStr(double d) {
            double off = date1904 ? 24107 : 25569;
            long ms = Math.round((d - off) * 86400000.0);
            boolean hasTime = ((ms % 86400000L) + 86400000L) % 86400000L != 0;
            String pat = d < 1 ? "HH:mm:ss" : (hasTime ? "dd/MM/yyyy HH:mm" : "dd/MM/yyyy");
            SimpleDateFormat sdf = new SimpleDateFormat(pat, Locale.US);
            sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
            return sdf.format(new java.util.Date(ms));
        }
    }

    // ------------------------------------------------------------ PPTX

    static class Pptx extends OfficeDoc {
        final List<String> slides = new ArrayList<>();
        final List<String> titles = new ArrayList<>();

        @Override int count() { return slides.size(); }

        @Override String sectionTitle(int i) { return titles.get(i); }

        @Override
        void init() throws Exception {
            Map<String, String> rels = rels(zip, "ppt/_rels/presentation.xml.rels", "ppt/");
            InputStream in = stream(zip, "ppt/presentation.xml");
            if (in == null) throw new Exception("Thiếu ppt/presentation.xml");
            try {
                XmlPullParser p = parser(in);
                for (int e = p.getEventType(); e != XmlPullParser.END_DOCUMENT; e = p.next()) {
                    if (e == XmlPullParser.START_TAG && nm(p).equals("sldId")) {
                        String path = rels.get(attr(p, "r:id"));
                        if (path != null && slides.size() < 500) slides.add(path);
                    }
                }
            } finally {
                in.close();
            }
            if (slides.isEmpty()) throw new Exception("Bản trình chiếu không có slide");
            for (int i = 0; i < slides.size(); i++) {
                String first = "";
                InputStream s = stream(zip, slides.get(i));
                if (s != null) {
                    try {
                        XmlPullParser p = parser(s);
                        for (int e = p.getEventType(); e != XmlPullParser.END_DOCUMENT; e = p.next()) {
                            if (e == XmlPullParser.START_TAG && nm(p).equals("t")) {
                                String t = p.nextText().trim();
                                if (!t.isEmpty()) {
                                    first = t.length() > 40 ? t.substring(0, 40) + "…" : t;
                                    break;
                                }
                            }
                        }
                    } catch (Exception ignored) {
                    } finally {
                        s.close();
                    }
                }
                titles.add("Slide " + (i + 1) + (first.isEmpty() ? "" : ": " + first));
            }
        }

        @Override
        String html(int idx, String css) throws Exception {
            String path = slides.get(idx);
            String file = path.substring(path.lastIndexOf('/') + 1);
            Map<String, String> rels = rels(zip, "ppt/slides/_rels/" + file + ".rels", "ppt/slides/");
            StringBuilder sb = new StringBuilder();
            StringBuilder para = new StringBuilder();
            boolean isTitle = false, b = false, i = false, u = false, bullet = false;
            int lvl = 0;
            ArrayDeque<Boolean> tdSkip = new ArrayDeque<>();

            InputStream in = stream(zip, path);
            if (in == null) throw new Exception("Thiếu " + path);
            try {
                XmlPullParser p = parser(in);
                for (int e = p.getEventType(); e != XmlPullParser.END_DOCUMENT; e = p.next()) {
                    if (e == XmlPullParser.START_TAG) {
                        String n = nm(p);
                        switch (n) {
                            case "sp":
                                isTitle = false;
                                break;
                            case "ph": {
                                String t = attr(p, "type");
                                if ("title".equals(t) || "ctrTitle".equals(t)) isTitle = true;
                                break;
                            }
                            case "p":
                                para.setLength(0);
                                bullet = false;
                                lvl = 0;
                                break;
                            case "pPr":
                                lvl = toInt(attr(p, "lvl"), 0);
                                break;
                            case "buChar":
                            case "buAutoNum":
                                bullet = true;
                                break;
                            case "buNone":
                                bullet = false;
                                break;
                            case "r":
                                b = false;
                                i = false;
                                u = false;
                                break;
                            case "rPr": {
                                b = "1".equals(attr(p, "b"));
                                i = "1".equals(attr(p, "i"));
                                String uu = attr(p, "u");
                                u = uu != null && !"none".equals(uu);
                                break;
                            }
                            case "t":
                                para.append(fmt(esc(p.nextText()), b, i, u, false));
                                break;
                            case "br":
                                para.append("<br>");
                                break;
                            case "blip": {
                                String ip = rels.get(attr(p, "r:embed"));
                                if (ip != null) sb.append("<p>").append(img(ip)).append("</p>");
                                break;
                            }
                            case "tbl":
                                sb.append("<table>");
                                break;
                            case "tr":
                                sb.append("<tr>");
                                break;
                            case "tc": {
                                boolean skipCell = "1".equals(attr(p, "hMerge")) || "1".equals(attr(p, "vMerge"));
                                tdSkip.push(skipCell);
                                if (!skipCell) {
                                    sb.append("<td");
                                    int gs = toInt(attr(p, "gridSpan"), 1);
                                    int rs = toInt(attr(p, "rowSpan"), 1);
                                    if (gs > 1) sb.append(" colspan=\"").append(gs).append("\"");
                                    if (rs > 1) sb.append(" rowspan=\"").append(rs).append("\"");
                                    sb.append(">");
                                }
                                break;
                            }
                            default:
                                break;
                        }
                    } else if (e == XmlPullParser.END_TAG) {
                        String n = nm(p);
                        if (n.equals("p")) {
                            String text = para.toString();
                            if (!text.replace("<br>", "").trim().isEmpty()) {
                                if (isTitle) {
                                    sb.append("<h2>").append(text).append("</h2>");
                                } else {
                                    sb.append("<p style=\"margin-left:").append(lvl * 22).append("px\">")
                                            .append(bullet ? "• " : "").append(text).append("</p>");
                                }
                            }
                        } else if (n.equals("sp")) {
                            isTitle = false;
                        } else if (n.equals("tc")) {
                            boolean skipCell = !tdSkip.isEmpty() && tdSkip.pop();
                            if (!skipCell) sb.append("</td>");
                        } else if (n.equals("tr")) {
                            sb.append("</tr>");
                        } else if (n.equals("tbl")) {
                            sb.append("</table>");
                        }
                    }
                }
            } finally {
                in.close();
            }
            return page(css, sb.toString());
        }
    }
}
