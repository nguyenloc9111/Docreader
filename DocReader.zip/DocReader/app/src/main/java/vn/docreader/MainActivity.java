package vn.docreader;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import android.util.LruCache;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AbsListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int REQ_OPEN = 1;
    private static final String HOST = "epub.local";
    private static final int MODE_HOME = 0, MODE_EPUB = 1, MODE_TXT = 2, MODE_PDF = 3;

    private static final String[] BG = {"#FFFFFF", "#F4ECD8", "#121212"};
    private static final String[] FG = {"#111111", "#3B2F1E", "#D8D8D8"};

    private SharedPreferences prefs;
    private TextView titleView, pageLabel;
    private FrameLayout content;
    private LinearLayout bottomBar;
    private Button btnToc, btnMinus, btnPlus, btnTheme;

    private int mode = MODE_HOME;
    private File currentFile;

    // EPUB / TXT
    private WebView web;
    private EpubBook book;
    private int chapter;
    private int pendingScroll;
    private String txtEscaped;

    // PDF
    private PdfRenderer pdf;
    private ParcelFileDescriptor pdfFd;
    private ListView pdfList;
    private LruCache<Integer, Bitmap> pdfCache;

    // ---------------------------------------------------------------- vòng đời

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("reader", MODE_PRIVATE);
        buildUi();
        if (!handleIntent(getIntent())) showHome();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (!handleIntent(intent)) showHome();
    }

    @Override
    protected void onPause() {
        savePos();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        closeDoc();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (mode != MODE_HOME) {
            showHome();
        } else {
            super.onBackPressed();
        }
    }

    // ---------------------------------------------------------------- giao diện

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private Button makeBtn(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.TRANSPARENT);
        b.setAllCaps(false);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(10), 0, dp(10), 0);
        b.setOnClickListener(l);
        return b;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setBackgroundColor(Color.parseColor("#1565C0"));
        titleView = new TextView(this);
        titleView.setTextColor(Color.WHITE);
        titleView.setTextSize(16);
        titleView.setSingleLine(true);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        titleView.setPadding(dp(12), 0, dp(4), 0);
        top.addView(titleView, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        btnToc = makeBtn("☰", v -> showToc());
        btnMinus = makeBtn("A−", v -> changeZoom(-10));
        btnPlus = makeBtn("A+", v -> changeZoom(10));
        btnTheme = makeBtn("◐", v -> cycleTheme());
        Button more = makeBtn("⋮", this::showMenu);
        for (Button b : new Button[]{btnToc, btnMinus, btnPlus, btnTheme, more}) {
            top.addView(b, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(48)));
        }
        root.addView(top, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));

        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL);
        bottomBar.setGravity(Gravity.CENTER_VERTICAL);
        bottomBar.setBackgroundColor(Color.parseColor("#1565C0"));
        Button prev = makeBtn("◀ Trước", v -> goRelative(-1));
        Button next = makeBtn("Sau ▶", v -> goRelative(1));
        pageLabel = new TextView(this);
        pageLabel.setTextColor(Color.WHITE);
        pageLabel.setTextSize(13);
        pageLabel.setGravity(Gravity.CENTER);
        pageLabel.setSingleLine(true);
        pageLabel.setEllipsize(android.text.TextUtils.TruncateAt.END);
        bottomBar.addView(prev, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)));
        bottomBar.addView(pageLabel, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        bottomBar.addView(next, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)));
        root.addView(bottomBar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));

        setContentView(root);
    }

    private void setChrome() {
        boolean reading = mode != MODE_HOME;
        btnToc.setVisibility(mode == MODE_EPUB ? View.VISIBLE : View.GONE);
        btnMinus.setVisibility(mode == MODE_EPUB || mode == MODE_TXT ? View.VISIBLE : View.GONE);
        btnPlus.setVisibility(mode == MODE_EPUB || mode == MODE_TXT ? View.VISIBLE : View.GONE);
        btnTheme.setVisibility(mode == MODE_EPUB || mode == MODE_TXT ? View.VISIBLE : View.GONE);
        bottomBar.setVisibility(mode == MODE_EPUB || mode == MODE_PDF ? View.VISIBLE : View.GONE);
        if (!reading) titleView.setText("Đọc Sách Offline");
    }

    private void showMenu(View anchor) {
        PopupMenu m = new PopupMenu(this, anchor);
        m.getMenu().add(0, 1, 0, "Thư viện");
        m.getMenu().add(0, 2, 1, "Mở file…");
        m.getMenu().add(0, 3, 2, "Chia sẻ ứng dụng cho điện thoại khác");
        m.setOnMenuItemClickListener(it -> {
            switch (it.getItemId()) {
                case 1: showHome(); break;
                case 2: pickFile(); break;
                case 3: shareApp(); break;
            }
            return true;
        });
        m.show();
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    // ---------------------------------------------------------------- màn hình thư viện

    private File libDir() {
        File d = new File(getFilesDir(), "library");
        d.mkdirs();
        return d;
    }

    private void showHome() {
        closeDoc();
        mode = MODE_HOME;
        setChrome();
        content.removeAllViews();

        LinearLayout home = new LinearLayout(this);
        home.setOrientation(LinearLayout.VERTICAL);
        home.setPadding(dp(16), dp(16), dp(16), dp(8));

        Button open = new Button(this);
        open.setText("📂  Mở sách (EPUB / PDF / TXT)");
        open.setAllCaps(false);
        open.setOnClickListener(v -> pickFile());
        home.addView(open);

        Button share = new Button(this);
        share.setText("📲  Chia sẻ ứng dụng cho điện thoại khác");
        share.setAllCaps(false);
        share.setOnClickListener(v -> shareApp());
        home.addView(share);

        TextView lib = new TextView(this);
        lib.setText("Thư viện (nhấn giữ để xoá)");
        lib.setTextSize(14);
        lib.setPadding(0, dp(16), 0, dp(6));
        home.addView(lib);

        File[] files = libDir().listFiles();
        final List<File> list = new ArrayList<>();
        if (files != null) list.addAll(Arrays.asList(files));
        Collections.sort(list, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));

        if (list.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText("Chưa có sách nào.\nNhấn “Mở sách”, hoặc nhấn vào một link/file .epub .pdf .txt — ứng dụng sẽ tự mở.");
            empty.setTextColor(Color.GRAY);
            home.addView(empty);
        } else {
            List<String> names = new ArrayList<>();
            for (File f : list) names.add(prettyName(f.getName()));
            ListView lv = new ListView(this);
            lv.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, names));
            lv.setOnItemClickListener((p, v, i, id) -> openFile(list.get(i)));
            lv.setOnItemLongClickListener((p, v, i, id) -> {
                new AlertDialog.Builder(this)
                        .setMessage("Xoá “" + names.get(i) + "” khỏi thư viện?")
                        .setPositiveButton("Xoá", (d, w) -> {
                            list.get(i).delete();
                            showHome();
                        })
                        .setNegativeButton("Huỷ", null)
                        .show();
                return true;
            });
            home.addView(lv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        }
        content.addView(home, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private static String prettyName(String n) {
        int d = n.lastIndexOf('.');
        return d > 0 ? n.substring(0, d) : n;
    }

    // ---------------------------------------------------------------- nhận file / link

    private void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/epub+zip", "application/pdf", "text/plain", "application/octet-stream"});
        startActivityForResult(i, REQ_OPEN);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_OPEN && res == RESULT_OK && data != null && data.getData() != null) {
            importAndOpen(data.getData());
        }
    }

    private boolean handleIntent(Intent i) {
        if (i != null && Intent.ACTION_VIEW.equals(i.getAction()) && i.getData() != null) {
            importAndOpen(i.getData());
            return true;
        }
        return false;
    }

    private String displayName(Uri uri) {
        String name = null;
        if ("content".equals(uri.getScheme())) {
            try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                if (c != null && c.moveToFirst()) name = c.getString(0);
            } catch (Exception ignored) { }
        }
        if (name == null || name.isEmpty()) name = uri.getLastPathSegment();
        if (name == null || name.isEmpty()) name = "sach";
        name = name.replaceAll("[\\\\/:*?\"<>|]", "_");
        int slash = name.lastIndexOf('/');
        if (slash >= 0) name = name.substring(slash + 1);
        return name;
    }

    /** Sao chép file vào thư viện nội bộ (để đọc offline lâu dài) rồi mở. */
    private void importAndOpen(final Uri uri) {
        closeDoc();
        mode = MODE_HOME;
        setChrome();
        content.removeAllViews();
        TextView t = new TextView(this);
        t.setText("Đang mở…");
        t.setGravity(Gravity.CENTER);
        content.addView(t, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        new Thread(() -> {
            try {
                String name = displayName(uri);
                File dest = new File(libDir(), name);
                File tmp = new File(libDir(), name + ".part");
                String scheme = uri.getScheme();
                if ("http".equals(scheme) || "https".equals(scheme)) {
                    download(uri.toString(), tmp);
                } else {
                    try (InputStream in = getContentResolver().openInputStream(uri)) {
                        if (in == null) throw new IOException("Không đọc được file");
                        copy(in, tmp);
                    }
                }
                if (dest.exists()) dest.delete();
                if (!tmp.renameTo(dest)) throw new IOException("Không lưu được file");
                runOnUiThread(() -> openFile(dest));
            } catch (Exception e) {
                runOnUiThread(() -> {
                    toast("Không mở được: " + e.getMessage());
                    showHome();
                });
            }
        }).start();
    }

    private static void copy(InputStream in, File out) throws IOException {
        try (OutputStream o = new FileOutputStream(out)) {
            byte[] buf = new byte[32768];
            int n;
            while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
        }
    }

    private static void download(String url, File out) throws IOException {
        String cur = url;
        for (int hop = 0; hop < 6; hop++) {
            HttpURLConnection c = (HttpURLConnection) new URL(cur).openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(30000);
            c.setInstanceFollowRedirects(false);
            int code = c.getResponseCode();
            if (code >= 300 && code < 400 && c.getHeaderField("Location") != null) {
                cur = new URL(new URL(cur), c.getHeaderField("Location")).toString();
                c.disconnect();
                continue;
            }
            if (code != 200) throw new IOException("Máy chủ trả về mã " + code);
            try (InputStream in = c.getInputStream()) {
                copy(in, out);
            } finally {
                c.disconnect();
            }
            return;
        }
        throw new IOException("Chuyển hướng quá nhiều lần");
    }

    // ---------------------------------------------------------------- mở tài liệu

    private String sniff(File f) throws IOException {
        byte[] h = new byte[4];
        try (FileInputStream in = new FileInputStream(f)) {
            int n = in.read(h);
            if (n >= 4 && h[0] == '%' && h[1] == 'P' && h[2] == 'D' && h[3] == 'F') return "pdf";
            if (n >= 2 && h[0] == 'P' && h[1] == 'K') return "epub";
        }
        return "txt";
    }

    private void openFile(File f) {
        closeDoc();
        currentFile = f;
        f.setLastModified(System.currentTimeMillis());
        try {
            String type = sniff(f);
            if (type.equals("pdf")) openPdf(f);
            else if (type.equals("epub")) openEpub(f);
            else openTxt(f);
        } catch (Throwable e) {
            closeDoc();
            toast("Không mở được file: " + e.getMessage());
            showHome();
        }
    }

    private void closeDoc() {
        savePos();
        currentFile = null;
        if (web != null) {
            web.stopLoading();
            if (web.getParent() != null) ((ViewGroup) web.getParent()).removeView(web);
        }
        if (book != null) {
            book.close();
            book = null;
        }
        txtEscaped = null;
        if (pdf != null) {
            try { pdf.close(); } catch (Exception ignored) { }
            pdf = null;
        }
        if (pdfFd != null) {
            try { pdfFd.close(); } catch (Exception ignored) { }
            pdfFd = null;
        }
        pdfList = null;
        if (pdfCache != null) {
            pdfCache.evictAll();
            pdfCache = null;
        }
    }

    private void savePos() {
        if (currentFile == null) return;
        String k = currentFile.getName();
        SharedPreferences.Editor e = prefs.edit();
        if (mode == MODE_EPUB && web != null) {
            e.putInt("ch_" + k, chapter);
            e.putInt("sc_" + k, web.getScrollY());
        } else if (mode == MODE_TXT && web != null) {
            e.putInt("sc_" + k, web.getScrollY());
        } else if (mode == MODE_PDF && pdfList != null) {
            e.putInt("pg_" + k, pdfList.getFirstVisiblePosition());
        }
        e.apply();
    }

    // ---------------------------------------------------------------- WebView (EPUB + TXT)

    private void ensureWeb() {
        if (web == null) {
            web = new WebView(this);
            WebSettings s = web.getSettings();
            s.setJavaScriptEnabled(false);
            s.setAllowFileAccess(false);
            s.setAllowContentAccess(false);
            s.setBlockNetworkLoads(false);
            web.setWebViewClient(new WebViewClient() {
                @Override
                public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                    return serve(r.getUrl());
                }

                @SuppressWarnings("deprecation")
                @Override
                public WebResourceResponse shouldInterceptRequest(WebView v, String url) {
                    return serve(Uri.parse(url));
                }

                @Override
                public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                    return navigate(r.getUrl());
                }

                @SuppressWarnings("deprecation")
                @Override
                public boolean shouldOverrideUrlLoading(WebView v, String url) {
                    return navigate(Uri.parse(url));
                }

                @Override
                public void onPageFinished(WebView v, String url) {
                    if (pendingScroll > 0) {
                        final int y = pendingScroll;
                        pendingScroll = 0;
                        v.postDelayed(() -> v.scrollTo(0, y), 200);
                    }
                }
            });
        }
        web.getSettings().setTextZoom(prefs.getInt("zoom", 110));
        web.setBackgroundColor(Color.parseColor(BG[theme()]));
        if (web.getParent() != null) ((ViewGroup) web.getParent()).removeView(web);
        content.removeAllViews();
        content.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private int theme() {
        return prefs.getInt("theme", 0);
    }

    private String css() {
        int t = theme();
        StringBuilder sb = new StringBuilder();
        sb.append("html,body{background:").append(BG[t]).append("!important;color:").append(FG[t]).append("!important}");
        sb.append("body{margin:0!important;padding:3% 4%!important;line-height:1.65!important;overflow-wrap:anywhere}");
        sb.append("img,svg,video{max-width:100%!important;height:auto!important}");
        if (t != 0) {
            sb.append("body *{color:inherit!important;background-color:transparent!important}");
        }
        return sb.toString();
    }

    private WebResourceResponse blocked() {
        return new WebResourceResponse("text/plain", "utf-8", 403, "Blocked", new HashMap<String, String>(),
                new ByteArrayInputStream(new byte[0]));
    }

    private WebResourceResponse serve(Uri u) {
        try {
            EpubBook b = book;
            if (b == null || !HOST.equals(u.getHost())) return blocked();
            String path = u.getPath();
            if (path == null) return blocked();
            if (path.startsWith("/")) path = path.substring(1);
            byte[] data = b.read(path);
            if (data == null) {
                return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", new HashMap<String, String>(),
                        new ByteArrayInputStream(new byte[0]));
            }
            String mime = mimeOf(path);
            if (mime.equals("text/html")) {
                String html = new String(data, StandardCharsets.UTF_8);
                String style = "<style>" + css() + "</style>";
                int idx = html.toLowerCase(Locale.ROOT).indexOf("</head>");
                html = idx >= 0 ? html.substring(0, idx) + style + html.substring(idx) : style + html;
                data = html.getBytes(StandardCharsets.UTF_8);
            }
            return new WebResourceResponse(mime, "utf-8", new ByteArrayInputStream(data));
        } catch (Exception e) {
            return blocked();
        }
    }

    private static String mimeOf(String path) {
        String p = path.toLowerCase(Locale.ROOT);
        if (p.endsWith(".xhtml") || p.endsWith(".html") || p.endsWith(".htm") || p.endsWith(".xml")) return "text/html";
        if (p.endsWith(".css")) return "text/css";
        if (p.endsWith(".jpg") || p.endsWith(".jpeg")) return "image/jpeg";
        if (p.endsWith(".png")) return "image/png";
        if (p.endsWith(".gif")) return "image/gif";
        if (p.endsWith(".webp")) return "image/webp";
        if (p.endsWith(".svg")) return "image/svg+xml";
        if (p.endsWith(".ttf")) return "font/ttf";
        if (p.endsWith(".otf")) return "font/otf";
        if (p.endsWith(".woff")) return "font/woff";
        if (p.endsWith(".woff2")) return "font/woff2";
        return "application/octet-stream";
    }

    /** Link bên trong sách -> chuyển chương; link ra ngoài -> chặn (đọc offline). */
    private boolean navigate(Uri u) {
        if (!HOST.equals(u.getHost())) return true;
        if (book != null && u.getPath() != null) {
            String p = u.getPath().startsWith("/") ? u.getPath().substring(1) : u.getPath();
            int idx = book.spine.indexOf(p);
            if (idx >= 0) {
                chapter = idx;
                updateLabel();
            }
        }
        return false;
    }

    // ---------------------------------------------------------------- EPUB

    private void openEpub(File f) throws Exception {
        book = EpubBook.open(f);
        if (book.spine.isEmpty()) throw new Exception("EPUB không có nội dung");
        mode = MODE_EPUB;
        setChrome();
        titleView.setText(book.title.isEmpty() ? prettyName(f.getName()) : book.title);
        ensureWeb();
        int ch = Math.max(0, Math.min(prefs.getInt("ch_" + f.getName(), 0), book.spine.size() - 1));
        loadChapter(ch, prefs.getInt("sc_" + f.getName(), 0));
    }

    private void loadChapter(int i, int scroll) {
        if (book == null) return;
        chapter = Math.max(0, Math.min(i, book.spine.size() - 1));
        pendingScroll = scroll;
        web.loadUrl("https://" + HOST + "/" + Uri.encode(book.spine.get(chapter), "/"));
        updateLabel();
    }

    private void updateLabel() {
        if (mode == MODE_EPUB && book != null) {
            pageLabel.setText((chapter + 1) + "/" + book.spine.size() + " · " + book.titleOf(chapter));
        }
    }

    private void showToc() {
        if (book == null) return;
        final String[] items = new String[book.spine.size()];
        for (int i = 0; i < items.length; i++) items[i] = book.titleOf(i);
        new AlertDialog.Builder(this)
                .setTitle("Mục lục")
                .setItems(items, (d, w) -> loadChapter(w, 0))
                .show();
    }

    // ---------------------------------------------------------------- TXT

    private void openTxt(File f) throws Exception {
        byte[] data;
        try (FileInputStream in = new FileInputStream(f)) {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[32768];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            data = bo.toByteArray();
        }
        String text = decodeText(data);
        txtEscaped = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
        mode = MODE_TXT;
        setChrome();
        titleView.setText(prettyName(f.getName()));
        ensureWeb();
        pendingScroll = prefs.getInt("sc_" + f.getName(), 0);
        renderTxt();
    }

    private void renderTxt() {
        if (txtEscaped == null) return;
        String html = "<html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
                + "<style>" + css() + "</style></head><body><div style=\"white-space:pre-wrap\">"
                + txtEscaped + "</div></body></html>";
        web.loadDataWithBaseURL("https://" + HOST + "/", html, "text/html", "utf-8", null);
    }

    private static String decodeText(byte[] b) {
        try {
            if (b.length >= 2 && (b[0] & 0xFF) == 0xFF && (b[1] & 0xFF) == 0xFE)
                return new String(b, 2, b.length - 2, "UTF-16LE");
            if (b.length >= 2 && (b[0] & 0xFF) == 0xFE && (b[1] & 0xFF) == 0xFF)
                return new String(b, 2, b.length - 2, "UTF-16BE");
            int off = (b.length >= 3 && (b[0] & 0xFF) == 0xEF && (b[1] & 0xFF) == 0xBB && (b[2] & 0xFF) == 0xBF) ? 3 : 0;
            try {
                return StandardCharsets.UTF_8.newDecoder()
                        .onMalformedInput(CodingErrorAction.REPORT)
                        .onUnmappableCharacter(CodingErrorAction.REPORT)
                        .decode(ByteBuffer.wrap(b, off, b.length - off)).toString();
            } catch (CharacterCodingException e) {
                // File tiếng Việt cũ thường là Windows-1258
                return new String(b, Charset.forName("windows-1258"));
            }
        } catch (Exception e) {
            return new String(b, StandardCharsets.ISO_8859_1);
        }
    }

    // ---------------------------------------------------------------- PDF

    private void openPdf(File f) throws Exception {
        pdfFd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
        pdf = new PdfRenderer(pdfFd);
        mode = MODE_PDF;
        setChrome();
        titleView.setText(prettyName(f.getName()));

        final int width = getResources().getDisplayMetrics().widthPixels;
        int cacheBytes = (int) Math.max(8L << 20, Runtime.getRuntime().maxMemory() / 6);
        pdfCache = new LruCache<Integer, Bitmap>(cacheBytes) {
            @Override
            protected int sizeOf(Integer k, Bitmap v) {
                return v.getByteCount();
            }
        };

        pdfList = new ListView(this);
        pdfList.setBackgroundColor(Color.parseColor("#777777"));
        pdfList.setDividerHeight(dp(6));
        pdfList.setAdapter(new BaseAdapter() {
            @Override public int getCount() { return pdf == null ? 0 : pdf.getPageCount(); }
            @Override public Object getItem(int i) { return i; }
            @Override public long getItemId(int i) { return i; }

            @Override
            public View getView(int pos, View convert, ViewGroup parent) {
                ImageView iv = convert instanceof ImageView ? (ImageView) convert : new ImageView(MainActivity.this);
                iv.setScaleType(ImageView.ScaleType.FIT_XY);
                Bitmap bmp = pdfCache == null ? null : pdfCache.get(pos);
                if (bmp == null) {
                    bmp = renderPage(pos, width);
                    if (pdfCache != null) pdfCache.put(pos, bmp);
                }
                iv.setImageBitmap(bmp);
                iv.setLayoutParams(new AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, bmp.getHeight()));
                return iv;
            }
        });
        pdfList.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override public void onScrollStateChanged(AbsListView v, int s) { }

            @Override
            public void onScroll(AbsListView v, int first, int visible, int total) {
                updateLabelPdf();
            }
        });
        content.removeAllViews();
        content.addView(pdfList, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        pdfList.setSelection(Math.min(prefs.getInt("pg_" + f.getName(), 0), pdf.getPageCount() - 1));
        updateLabelPdf();
    }

    private void updateLabelPdf() {
        if (mode == MODE_PDF && pdf != null && pdfList != null) {
            pageLabel.setText("Trang " + (pdfList.getFirstVisiblePosition() + 1) + " / " + pdf.getPageCount());
        }
    }

    private Bitmap renderPage(int index, int width) {
        try {
            PdfRenderer r = pdf;
            if (r == null) throw new IllegalStateException();
            synchronized (r) {
                PdfRenderer.Page page = r.openPage(index);
                try {
                    int h = Math.max(1, (int) ((long) width * page.getHeight() / Math.max(1, page.getWidth())));
                    Bitmap bmp = Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888);
                    bmp.eraseColor(Color.WHITE);
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                    return bmp;
                } finally {
                    page.close();
                }
            }
        } catch (Exception e) {
            Bitmap bmp = Bitmap.createBitmap(width, dp(120), Bitmap.Config.ARGB_8888);
            bmp.eraseColor(Color.WHITE);
            return bmp;
        }
    }

    // ---------------------------------------------------------------- nút điều khiển

    private void goRelative(int d) {
        if (mode == MODE_EPUB && book != null) {
            int n = chapter + d;
            if (n >= 0 && n < book.spine.size()) loadChapter(n, 0);
        } else if (mode == MODE_PDF && pdfList != null) {
            int n = Math.max(0, Math.min(pdfList.getFirstVisiblePosition() + d, pdf.getPageCount() - 1));
            pdfList.setSelection(n);
        }
    }

    private void changeZoom(int delta) {
        if (web == null) return;
        int z = Math.max(60, Math.min(260, prefs.getInt("zoom", 110) + delta));
        prefs.edit().putInt("zoom", z).apply();
        web.getSettings().setTextZoom(z);
    }

    private void cycleTheme() {
        prefs.edit().putInt("theme", (theme() + 1) % 3).apply();
        if (web == null) return;
        web.setBackgroundColor(Color.parseColor(BG[theme()]));
        pendingScroll = web.getScrollY();
        if (mode == MODE_EPUB) loadChapter(chapter, pendingScroll);
        else if (mode == MODE_TXT) renderTxt();
    }

    // ---------------------------------------------------------------- chia sẻ ứng dụng

    /** Gửi chính file APK của ứng dụng qua Zalo / Bluetooth / Quick Share... */
    private void shareApp() {
        new Thread(() -> {
            try {
                File out = ApkProvider.apkFile(this);
                out.getParentFile().mkdirs();
                try (InputStream in = new FileInputStream(getApplicationInfo().sourceDir)) {
                    copy(in, out);
                }
                runOnUiThread(() -> {
                    Uri uri = Uri.parse("content://" + getPackageName() + ".apk/" + ApkProvider.FILE_NAME);
                    Intent s = new Intent(Intent.ACTION_SEND);
                    s.setType("application/vnd.android.package-archive");
                    s.putExtra(Intent.EXTRA_STREAM, uri);
                    s.putExtra(Intent.EXTRA_TEXT, "Ứng dụng Đọc Sách Offline (EPUB/PDF/TXT). Cài file này để đọc sách không cần mạng.");
                    s.setClipData(ClipData.newRawUri("apk", uri));
                    s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(s, "Chia sẻ ứng dụng"));
                });
            } catch (Exception e) {
                runOnUiThread(() -> toast("Không chia sẻ được: " + e.getMessage()));
            }
        }).start();
    }
}
