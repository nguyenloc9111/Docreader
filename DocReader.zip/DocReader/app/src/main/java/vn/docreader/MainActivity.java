package vn.docreader;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.LruCache;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AbsListView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.Charset;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int REQ_OPEN = 1;
    private static final String HOST = "epub.local";
    private static final int MODE_HOME = 0, MODE_EPUB = 1, MODE_TXT = 2, MODE_PDF = 3, MODE_OFFICE = 4;

    private static final String[] BG = {"#FFFFFF", "#F4ECD8", "#121212"};
    private static final String[] FG = {"#111111", "#3B2F1E", "#D8D8D8"};

    private SharedPreferences prefs;
    private TextView titleView, pageLabel;
    private FrameLayout content;
    private LinearLayout bottomBar;
    private Button btnToc, btnMinus, btnPlus, btnTheme;

    private int mode = MODE_HOME;
    private File currentFile;

    // EPUB / TXT
    private WebView web;
    private EpubBook book;
    private int chapter;
    private int pendingScroll;
    private String txtEscaped;

    // Office (docx / xlsx / pptx)
    private OfficeDoc office;
    private int section;
    private int loadToken;

    // Màn hình chính
    private String filter = "all";
    private int tab = -1; // 0 gần đây, 1 thiết bị, 2 dấu trang
    private String query = "";
    private List<File> deviceFiles;
    private boolean scanning, lastAccess;
    private final List<File> shown = new ArrayList<>();
    private BaseAdapter homeAdapter;
    private LinearLayout chipsBox, tabsBox;
    private TextView emptyView;

    // PDF
    private PdfRenderer pdf;
    private ParcelFileDescriptor pdfFd;
    private ListView pdfList;
    private LruCache<Integer, Bitmap> pdfCache;

    // ---------------------------------------------------------------- vòng đời

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("reader", MODE_PRIVATE);
        buildUi();
        if (!handleIntent(getIntent())) showHome();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (!handleIntent(intent)) showHome();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mode == MODE_HOME && hasAccess() != lastAccess) showHome();
    }

    @Override
    protected void onPause() {
        savePos();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        closeDoc();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (mode != MODE_HOME) {
            showHome();
        } else {
            super.onBackPressed();
        }
    }

    // ---------------------------------------------------------------- giao diện

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private Button makeBtn(String text, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(Color.TRANSPARENT);
        b.setAllCaps(false);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(10), 0, dp(10), 0);
        b.setOnClickListener(l);
        return b;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setBackgroundColor(Color.parseColor("#1565C0"));
        titleView = new TextView(this);
        titleView.setTextColor(Color.WHITE);
        titleView.setTextSize(16);
        titleView.setSingleLine(true);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        titleView.setPadding(dp(12), 0, dp(4), 0);
        top.addView(titleView, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        btnToc = makeBtn("☰", v -> showToc());
        btnMinus = makeBtn("A−", v -> changeZoom(-10));
        btnPlus = makeBtn("A+", v -> changeZoom(10));
        btnTheme = makeBtn("◐", v -> cycleTheme());
        Button more = makeBtn("⋮", this::showMenu);
        for (Button b : new Button[]{btnToc, btnMinus, btnPlus, btnTheme, more}) {
            top.addView(b, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(48)));
        }
        root.addView(top, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(48)));

        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        bottomBar = new LinearLayout(this);
        bottomBar.setOrientation(LinearLayout.HORIZONTAL);
        bottomBar.setGravity(Gravity.CENTER_VERTICAL);
        bottomBar.setBackgroundColor(Color.parseColor("#1565C0"));
        Button prev = makeBtn("◀ Trước", v -> goRelative(-1));
        Button next = makeBtn("Sau ▶", v -> goRelative(1));
        pageLabel = new TextView(this);
        pageLabel.setTextColor(Color.WHITE);
        pageLabel.setTextSize(13);
        pageLabel.setGravity(Gravity.CENTER);
        pageLabel.setSingleLine(true);
        pageLabel.setEllipsize(android.text.TextUtils.TruncateAt.END);
        bottomBar.addView(prev, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)));
        bottomBar.addView(pageLabel, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        bottomBar.addView(next, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(44)));
        root.addView(bottomBar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));

        setContentView(root);
    }

    private void setChrome() {
        boolean reading = mode != MODE_HOME;
        boolean web = mode == MODE_EPUB || mode == MODE_TXT || mode == MODE_OFFICE;
        boolean multi = mode == MODE_EPUB || (mode == MODE_OFFICE && office != null && office.count() > 1);
        btnToc.setVisibility(multi ? View.VISIBLE : View.GONE);
        btnMinus.setVisibility(web ? View.VISIBLE : View.GONE);
        btnPlus.setVisibility(web ? View.VISIBLE : View.GONE);
        btnTheme.setVisibility(web ? View.VISIBLE : View.GONE);
        bottomBar.setVisibility(multi || mode == MODE_PDF ? View.VISIBLE : View.GONE);
        if (!reading) titleView.setText("Đọc Tài Liệu v1.2");
    }

    private void showMenu(View anchor) {
        PopupMenu m = new PopupMenu(this, anchor);
        m.getMenu().add(0, 1, 0, "Màn hình chính");
        m.getMenu().add(0, 2, 1, "Mở file…");
        m.getMenu().add(0, 4, 2, "Quét lại file trong máy");
        m.getMenu().add(0, 3, 3, "Chia sẻ ứng dụng cho điện thoại khác");
        m.setOnMenuItemClickListener(it -> {
            switch (it.getItemId()) {
                case 1: showHome(); break;
                case 2: pickFile(); break;
                case 3: shareApp(); break;
                case 4:
                    deviceFiles = null;
                    showHome();
                    break;
            }
            return true;
        });
        m.show();
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    // ---------------------------------------------------------------- màn hình thư viện

    private File libDir() {
        File d = new File(getFilesDir(), "library");
        d.mkdirs();
        return d;
    }

    private static final String[][] CATS = {
            {"all", "Tất cả"}, {"pdf", "PDF"}, {"word", "Word"}, {"excel", "Excel"},
            {"ppt", "PPT"}, {"txt", "TXT"}, {"epub", "EPUB"}};

    private static String extOf(File f) {
        String n = f.getName();
        int d = n.lastIndexOf('.');
        return d < 0 ? "" : n.substring(d + 1).toLowerCase(Locale.ROOT);
    }

    private static String catOf(String e) {
        switch (e) {
            case "pdf": return "pdf";
            case "doc": case "docx": return "word";
            case "xls": case "xlsx": return "excel";
            case "ppt": case "pptx": return "ppt";
            case "txt": return "txt";
            case "epub": return "epub";
            default: return null;
        }
    }

    private static int colorOf(String cat) {
        if (cat == null) return Color.GRAY;
        switch (cat) {
            case "pdf": return Color.parseColor("#D32F2F");
            case "word": return Color.parseColor("#1565C0");
            case "excel": return Color.parseColor("#2E7D32");
            case "ppt": return Color.parseColor("#E64A19");
            case "epub": return Color.parseColor("#6A1B9A");
            default: return Color.parseColor("#546E7A");
        }
    }

    private boolean hasAccess() {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        if (Build.VERSION.SDK_INT >= 23) {
            return checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        }
        return true;
    }

    private void grantAccess() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                        Uri.parse("package:" + getPackageName())));
            } catch (Exception e) {
                try {
                    startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                } catch (Exception e2) {
                    toast("Hãy vào Cài đặt > Ứng dụng > Đọc Tài Liệu > Quyền > Tệp và phương tiện");
                }
            }
        } else if (Build.VERSION.SDK_INT >= 23) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 7);
        }
    }

    // ---- danh sách gần đây / dấu trang (lưu đường dẫn trong SharedPreferences)

    private List<File> loadList(String key) {
        List<File> out = new ArrayList<>();
        String raw = prefs.getString(key, "");
        for (String line : raw.split("\n")) {
            if (line.isEmpty()) continue;
            File f = new File(line);
            if (f.isFile()) out.add(f);
        }
        return out;
    }

    private void saveList(String key, List<File> list) {
        StringBuilder sb = new StringBuilder();
        for (File f : list) sb.append(f.getAbsolutePath()).append('\n');
        prefs.edit().putString(key, sb.toString()).apply();
    }

    private void addRecent(File f) {
        List<File> l = loadList("recent");
        for (int i = l.size() - 1; i >= 0; i--) if (l.get(i).equals(f)) l.remove(i);
        l.add(0, f);
        while (l.size() > 60) l.remove(l.size() - 1);
        saveList("recent", l);
    }

    private void removeRecent(File f) {
        List<File> l = loadList("recent");
        l.remove(f);
        saveList("recent", l);
    }

    private boolean isBookmarked(File f) {
        return loadList("bookmarks").contains(f);
    }

    private void toggleBookmark(File f) {
        List<File> l = loadList("bookmarks");
        if (!l.remove(f)) l.add(0, f);
        saveList("bookmarks", l);
    }

    // ---- quét file trong máy

    private void startScan() {
        if (scanning) return;
        scanning = true;
        new Thread(() -> {
            final List<File> out = new ArrayList<>();
            try {
                walk(Environment.getExternalStorageDirectory(), 0, out);
                File[] lib = libDir().listFiles();
                if (lib != null) {
                    for (File f : lib) if (catOf(extOf(f)) != null) out.add(f);
                }
            } catch (Throwable ignored) { }
            Collections.sort(out, (x, y) -> Long.compare(y.lastModified(), x.lastModified()));
            runOnUiThread(() -> {
                scanning = false;
                deviceFiles = out;
                if (mode == MODE_HOME && homeAdapter != null) {
                    buildChips();
                    buildTabs();
                    refreshList();
                }
            });
        }).start();
    }

    private static void walk(File dir, int depth, List<File> out) {
        if (depth > 12 || out.size() > 30000) return;
        File[] fs = dir.listFiles();
        if (fs == null) return;
        for (File f : fs) {
            String n = f.getName();
            if (n.startsWith(".")) continue;
            if (f.isDirectory()) {
                if (depth == 0 && n.equals("Android")) continue;
                walk(f, depth + 1, out);
            } else if (catOf(extOf(f)) != null) {
                out.add(f);
            }
        }
    }

    // ---- màn hình chính

    private GradientDrawable pill(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(radiusDp));
        return g;
    }

    private void showHome() {
        closeDoc();
        mode = MODE_HOME;
        setChrome();
        content.removeAllViews();
        lastAccess = hasAccess();
        if (lastAccess && deviceFiles == null) startScan();
        if (tab < 0) tab = loadList("recent").isEmpty() ? 1 : 0;

        LinearLayout home = new LinearLayout(this);
        home.setOrientation(LinearLayout.VERTICAL);

        if (!lastAccess) {
            LinearLayout banner = new LinearLayout(this);
            banner.setOrientation(LinearLayout.HORIZONTAL);
            banner.setGravity(Gravity.CENTER_VERTICAL);
            banner.setBackgroundColor(Color.parseColor("#FFF3E0"));
            banner.setPadding(dp(12), dp(8), dp(8), dp(8));
            TextView bt = new TextView(this);
            bt.setText("Cấp quyền truy cập tất cả file để tự tìm tài liệu trong máy.");
            bt.setTextSize(13);
            bt.setTextColor(Color.parseColor("#5D4037"));
            banner.addView(bt, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            Button grant = new Button(this);
            grant.setText("Cấp quyền");
            grant.setAllCaps(false);
            grant.setOnClickListener(v -> grantAccess());
            banner.addView(grant);
            home.addView(banner, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        }

        EditText search = new EditText(this);
        search.setHint("🔍  Tìm tài liệu");
        search.setSingleLine(true);
        search.setText(query);
        search.setTextSize(15);
        search.setPadding(dp(14), dp(8), dp(14), dp(8));
        search.setBackground(pill(Color.parseColor("#EEEEEE"), 22));
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence c, int a, int b, int d) { }
            @Override public void onTextChanged(CharSequence c, int a, int b, int d) { }

            @Override
            public void afterTextChanged(Editable e) {
                query = e.toString().trim();
                refreshList();
            }
        });
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sp.setMargins(dp(12), dp(10), dp(12), dp(4));
        home.addView(search, sp);

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        chipsBox = new LinearLayout(this);
        chipsBox.setOrientation(LinearLayout.HORIZONTAL);
        chipsBox.setPadding(dp(8), dp(4), dp(8), dp(4));
        hs.addView(chipsBox);
        home.addView(hs, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        tabsBox = new LinearLayout(this);
        tabsBox.setOrientation(LinearLayout.HORIZONTAL);
        home.addView(tabsBox, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(44)));

        FrameLayout listBox = new FrameLayout(this);
        ListView lv = new ListView(this);
        lv.setDividerHeight(0);
        homeAdapter = new BaseAdapter() {
            @Override public int getCount() { return shown.size(); }
            @Override public Object getItem(int i) { return shown.get(i); }
            @Override public long getItemId(int i) { return i; }

            @Override
            public View getView(int pos, View convert, ViewGroup parent) {
                return rowView(shown.get(pos));
            }
        };
        lv.setAdapter(homeAdapter);
        lv.setOnItemClickListener((pp, v, i, id) -> {
            if (i < shown.size()) openFile(shown.get(i));
        });
        lv.setOnItemLongClickListener((pp, v, i, id) -> {
            if (i < shown.size()) itemMenu(shown.get(i));
            return true;
        });
        listBox.addView(lv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        emptyView = new TextView(this);
        emptyView.setTextColor(Color.GRAY);
        emptyView.setGravity(Gravity.CENTER);
        emptyView.setPadding(dp(24), dp(24), dp(24), dp(24));
        listBox.addView(emptyView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        home.addView(listBox, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        Button open = new Button(this);
        open.setText("📂 Mở file…");
        open.setAllCaps(false);
        open.setOnClickListener(v -> pickFile());
        Button share = new Button(this);
        share.setText("📲 Chia sẻ app");
        share.setAllCaps(false);
        share.setOnClickListener(v -> shareApp());
        bar.addView(open, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        bar.addView(share, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        home.addView(bar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        content.addView(home, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        buildChips();
        buildTabs();
        refreshList();
    }

    private int countOf(String cat) {
        if (deviceFiles == null) return 0;
        if (cat.equals("all")) return deviceFiles.size();
        int n = 0;
        for (File f : deviceFiles) if (cat.equals(catOf(extOf(f)))) n++;
        return n;
    }

    private void buildChips() {
        if (chipsBox == null) return;
        chipsBox.removeAllViews();
        for (String[] c : CATS) {
            final String cat = c[0];
            boolean sel = cat.equals(filter);
            TextView t = new TextView(this);
            t.setText(c[1] + (deviceFiles == null ? "" : " " + countOf(cat)));
            t.setTextSize(13);
            t.setPadding(dp(14), dp(7), dp(14), dp(7));
            t.setTextColor(sel ? Color.WHITE : Color.parseColor("#333333"));
            t.setBackground(pill(sel ? Color.parseColor("#1565C0") : Color.parseColor("#E8EAF0"), 18));
            t.setOnClickListener(v -> {
                filter = cat;
                buildChips();
                refreshList();
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(dp(4), 0, dp(4), 0);
            chipsBox.addView(t, lp);
        }
    }

    private void buildTabs() {
        if (tabsBox == null) return;
        tabsBox.removeAllViews();
        String[] names = {"Gần đây", "Thiết bị", "Dấu trang"};
        for (int i = 0; i < names.length; i++) {
            final int k = i;
            TextView t = new TextView(this);
            t.setText(names[i]);
            t.setGravity(Gravity.CENTER);
            t.setTextSize(14);
            boolean sel = tab == i;
            t.setTextColor(sel ? Color.parseColor("#1565C0") : Color.GRAY);
            t.setTypeface(null, sel ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
            t.setBackgroundColor(sel ? Color.parseColor("#E3EDFB") : Color.TRANSPARENT);
            t.setOnClickListener(v -> {
                tab = k;
                buildTabs();
                refreshList();
            });
            tabsBox.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        }
    }

    private void refreshList() {
        if (homeAdapter == null) return;
        List<File> base;
        if (tab == 0) base = loadList("recent");
        else if (tab == 2) base = loadList("bookmarks");
        else base = deviceFiles == null ? new ArrayList<File>() : deviceFiles;
        String q = query.toLowerCase(Locale.ROOT);
        shown.clear();
        for (File f : base) {
            String cat = catOf(extOf(f));
            if (!filter.equals("all") && !filter.equals(cat)) continue;
            if (!q.isEmpty() && !f.getName().toLowerCase(Locale.ROOT).contains(q)) continue;
            shown.add(f);
        }
        homeAdapter.notifyDataSetChanged();
        String msg = "";
        if (shown.isEmpty()) {
            if (tab == 1 && !hasAccess()) msg = "Chưa có quyền xem file trong máy.\nBấm “Cấp quyền” ở trên, hoặc dùng “Mở file…”.";
            else if (tab == 1 && (deviceFiles == null || scanning)) msg = "Đang tìm tài liệu trong máy…";
            else if (tab == 0) msg = "Chưa có tài liệu nào đọc gần đây.\nChọn tab “Thiết bị” để xem file trong máy.";
            else if (tab == 2) msg = "Chưa có dấu trang.\nBấm ☆ cạnh tên file để đánh dấu.";
            else msg = "Không tìm thấy tài liệu phù hợp.";
        }
        emptyView.setText(msg);
        emptyView.setVisibility(msg.isEmpty() ? View.GONE : View.VISIBLE);
    }

    private static String sizeStr(long b) {
        if (b < 1024) return b + " B";
        if (b < 1024 * 1024) return (b / 1024) + " KB";
        return String.format(Locale.US, "%.1f MB", b / 1048576.0);
    }

    private View rowView(final File f) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(12), dp(8), dp(4), dp(8));

        String ext = extOf(f);
        TextView badge = new TextView(this);
        badge.setText(ext.toUpperCase(Locale.ROOT));
        badge.setTextColor(Color.WHITE);
        badge.setTextSize(11);
        badge.setTypeface(null, android.graphics.Typeface.BOLD);
        badge.setGravity(Gravity.CENTER);
        badge.setBackground(pill(colorOf(catOf(ext)), 8));
        row.addView(badge, new LinearLayout.LayoutParams(dp(44), dp(44)));

        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.setPadding(dp(12), 0, dp(8), 0);
        TextView name = new TextView(this);
        name.setText(prettyName(f.getName()));
        name.setTextSize(15);
        name.setTextColor(Color.parseColor("#111111"));
        name.setSingleLine(true);
        name.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
        TextView sub = new TextView(this);
        sub.setText(sizeStr(f.length()) + "  ·  " + new SimpleDateFormat("dd/MM/yyyy", Locale.US).format(new Date(f.lastModified())));
        sub.setTextSize(12);
        sub.setTextColor(Color.GRAY);
        sub.setSingleLine(true);
        mid.addView(name);
        mid.addView(sub);
        row.addView(mid, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        final TextView star = new TextView(this);
        boolean bm = isBookmarked(f);
        star.setText(bm ? "★" : "☆");
        star.setTextSize(24);
        star.setTextColor(bm ? Color.parseColor("#F9A825") : Color.GRAY);
        star.setGravity(Gravity.CENTER);
        star.setFocusable(false);
        star.setOnClickListener(v -> {
            toggleBookmark(f);
            if (tab == 2) refreshList();
            else homeAdapter.notifyDataSetChanged();
        });
        row.addView(star, new LinearLayout.LayoutParams(dp(48), dp(48)));
        return row;
    }

    private void itemMenu(final File f) {
        final boolean inLib = f.getParentFile() != null && f.getParentFile().equals(libDir());
        List<String> items = new ArrayList<>();
        items.add("Xoá khỏi Gần đây");
        if (inLib) items.add("Xoá file đã nhập khỏi ứng dụng");
        new AlertDialog.Builder(this)
                .setTitle(prettyName(f.getName()))
                .setItems(items.toArray(new String[0]), (d, w) -> {
                    if (w == 0) {
                        removeRecent(f);
                    } else {
                        f.delete();
                        removeRecent(f);
                        if (deviceFiles != null) deviceFiles.remove(f);
                        buildChips();
                    }
                    refreshList();
                })
                .show();
    }

    private static String prettyName(String n) {
        int d = n.lastIndexOf('.');
        return d > 0 ? n.substring(0, d) : n;
    }

    // ---------------------------------------------------------------- nhận file / link

    private void pickFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "application/epub+zip", "application/pdf", "text/plain", "application/octet-stream",
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "application/vnd.openxmlformats-officedocument.presentationml.presentation"});
        startActivityForResult(i, REQ_OPEN);
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_OPEN && res == RESULT_OK && data != null && data.getData() != null) {
            importAndOpen(data.getData());
        }
    }

    private boolean handleIntent(Intent i) {
        if (i != null && Intent.ACTION_VIEW.equals(i.getAction()) && i.getData() != null) {
            importAndOpen(i.getData());
            return true;
        }
        return false;
    }

    private String displayName(Uri uri) {
        String name = null;
        if ("content".equals(uri.getScheme())) {
            try (Cursor c = getContentResolver().query(uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
                if (c != null && c.moveToFirst()) name = c.getString(0);
            } catch (Exception ignored) { }
        }
        if (name == null || name.isEmpty()) name = uri.getLastPathSegment();
        if (name == null || name.isEmpty()) name = "sach";
        name = name.replaceAll("[\\\\/:*?\"<>|]", "_");
        int slash = name.lastIndexOf('/');
        if (slash >= 0) name = name.substring(slash + 1);
        return name;
    }

    /** Sao chép file vào thư viện nội bộ (để đọc offline lâu dài) rồi mở. */
    private void importAndOpen(final Uri uri) {
        closeDoc();
        mode = MODE_HOME;
        setChrome();
        content.removeAllViews();
        TextView t = new TextView(this);
        t.setText("Đang mở…");
        t.setGravity(Gravity.CENTER);
        content.addView(t, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        new Thread(() -> {
            try {
                String name = displayName(uri);
                File dest = new File(libDir(), name);
                File tmp = new File(libDir(), name + ".part");
                String scheme = uri.getScheme();
                if ("http".equals(scheme) || "https".equals(scheme)) {
                    download(uri.toString(), tmp);
                } else {
                    try (InputStream in = getContentResolver().openInputStream(uri)) {
                        if (in == null) throw new IOException("Không đọc được file");
                        copy(in, tmp);
                    }
                }
                if (dest.exists()) dest.delete();
                if (!tmp.renameTo(dest)) throw new IOException("Không lưu được file");
                runOnUiThread(() -> openFile(dest));
            } catch (Exception e) {
                runOnUiThread(() -> {
                    toast("Không mở được: " + e.getMessage());
                    showHome();
                });
            }
        }).start();
    }

    private static void copy(InputStream in, File out) throws IOException {
        try (OutputStream o = new FileOutputStream(out)) {
            byte[] buf = new byte[32768];
            int n;
            while ((n = in.read(buf)) > 0) o.write(buf, 0, n);
        }
    }

    private static void download(String url, File out) throws IOException {
        String cur = url;
        for (int hop = 0; hop < 6; hop++) {
            HttpURLConnection c = (HttpURLConnection) new URL(cur).openConnection();
            c.setConnectTimeout(15000);
            c.setReadTimeout(30000);
            c.setInstanceFollowRedirects(false);
            int code = c.getResponseCode();
            if (code >= 300 && code < 400 && c.getHeaderField("Location") != null) {
                cur = new URL(new URL(cur), c.getHeaderField("Location")).toString();
                c.disconnect();
                continue;
            }
            if (code != 200) throw new IOException("Máy chủ trả về mã " + code);
            try (InputStream in = c.getInputStream()) {
                copy(in, out);
            } finally {
                c.disconnect();
            }
            return;
        }
        throw new IOException("Chuyển hướng quá nhiều lần");
    }

    // ---------------------------------------------------------------- mở tài liệu

    private String sniff(File f) throws IOException {
        byte[] h = new byte[1024];
        int n;
        try (FileInputStream in = new FileInputStream(f)) {
            n = in.read(h);
        }
        for (int i = 0; i + 3 < n; i++) {
            if (h[i] == '%' && h[i + 1] == 'P' && h[i + 2] == 'D' && h[i + 3] == 'F') return "pdf";
        }
        if (n >= 4 && (h[0] & 0xFF) == 0xD0 && (h[1] & 0xFF) == 0xCF && (h[2] & 0xFF) == 0x11 && (h[3] & 0xFF) == 0xE0) {
            return "ole";
        }
        if (n >= 2 && h[0] == 'P' && h[1] == 'K') {
            java.util.zip.ZipFile z = new java.util.zip.ZipFile(f);
            try {
                String k = OfficeDoc.kindOf(z);
                if (k == null) throw new IOException("File nén này không phải tài liệu được hỗ trợ");
                return k;
            } finally {
                z.close();
            }
        }
        return "txt";
    }

    private String key(File f) {
        return f.getAbsolutePath();
    }

    private void openFile(File f) {
        closeDoc();
        currentFile = f;
        File lib = f.getParentFile();
        if (lib != null && lib.equals(libDir())) f.setLastModified(System.currentTimeMillis());
        try {
            String type = sniff(f);
            if (type.equals("ole")) {
                currentFile = null;
                showHome();
                new AlertDialog.Builder(this)
                        .setMessage("File .doc / .xls / .ppt (định dạng Office cũ) chưa được hỗ trợ.\n\n"
                                + "Hãy lưu lại thành .docx / .xlsx / .pptx rồi mở lại.")
                        .setPositiveButton("Đóng", null)
                        .show();
                return;
            }
            if (type.equals("pdf")) openPdf(f);
            else if (type.equals("epub")) openEpub(f);
            else if (type.equals("txt")) openTxt(f);
            else openOffice(f, type);
            addRecent(f);
        } catch (Throwable e) {
            closeDoc();
            android.util.Log.e("DocReader", "open failed", e);
            StackTraceElement[] st = e.getStackTrace();
            String where = st.length > 0 ? st[0].getFileName() + ":" + st[0].getLineNumber() : "";
            toast("Không mở được " + f.getName() + "\n" + e.getClass().getSimpleName() + ": " + e.getMessage() + " (" + where + ")");
            showHome();
        }
    }

    private void closeDoc() {
        savePos();
        currentFile = null;
        if (web != null) {
            web.stopLoading();
            if (web.getParent() != null) ((ViewGroup) web.getParent()).removeView(web);
        }
        if (book != null) {
            book.close();
            book = null;
        }
        txtEscaped = null;
        loadToken++;
        if (office != null) {
            office.close();
            office = null;
        }
        if (pdf != null) {
            try { pdf.close(); } catch (Exception ignored) { }
            pdf = null;
        }
        if (pdfFd != null) {
            try { pdfFd.close(); } catch (Exception ignored) { }
            pdfFd = null;
        }
        pdfList = null;
        if (pdfCache != null) {
            pdfCache.evictAll();
            pdfCache = null;
        }
    }

    private void savePos() {
        if (currentFile == null) return;
        String k = key(currentFile);
        SharedPreferences.Editor e = prefs.edit();
        if (mode == MODE_OFFICE && web != null) {
            e.putInt("ch_" + k, section);
            e.putInt("sc_" + k, web.getScrollY());
        } else if (mode == MODE_EPUB && web != null) {
            e.putInt("ch_" + k, chapter);
            e.putInt("sc_" + k, web.getScrollY());
        } else if (mode == MODE_TXT && web != null) {
            e.putInt("sc_" + k, web.getScrollY());
        } else if (mode == MODE_PDF && pdfList != null) {
            e.putInt("pg_" + k, pdfList.getFirstVisiblePosition());
        }
        e.apply();
    }

    // ---------------------------------------------------------------- WebView (EPUB + TXT)

    private void ensureWeb() {
        if (web == null) {
            web = new WebView(this);
            WebSettings s = web.getSettings();
            s.setJavaScriptEnabled(false);
            s.setAllowFileAccess(false);
            s.setAllowContentAccess(false);
            s.setBlockNetworkLoads(false);
            web.setWebViewClient(new WebViewClient() {
                @Override
                public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                    return serve(r.getUrl());
                }

                @SuppressWarnings("deprecation")
                @Override
                public WebResourceResponse shouldInterceptRequest(WebView v, String url) {
                    return serve(Uri.parse(url));
                }

                @Override
                public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                    return navigate(r.getUrl());
                }

                @SuppressWarnings("deprecation")
                @Override
                public boolean shouldOverrideUrlLoading(WebView v, String url) {
                    return navigate(Uri.parse(url));
                }

                @SuppressWarnings("deprecation")
                @Override
                public void onReceivedError(WebView v, int code, String desc, String url) {
                    toast("Lỗi hiển thị: " + desc + " (" + code + ")");
                }

                @Override
                public void onPageFinished(WebView v, String url) {
                    if (pendingScroll > 0) {
                        final int y = pendingScroll;
                        pendingScroll = 0;
                        v.postDelayed(() -> v.scrollTo(0, y), 200);
                    }
                }
            });
        }
        web.getSettings().setTextZoom(prefs.getInt("zoom", 110));
        web.setBackgroundColor(Color.parseColor(BG[theme()]));
        if (web.getParent() != null) ((ViewGroup) web.getParent()).removeView(web);
        content.removeAllViews();
        content.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private int theme() {
        return prefs.getInt("theme", 0);
    }

    private String css() {
        int t = theme();
        StringBuilder sb = new StringBuilder();
        sb.append("html,body{background:").append(BG[t]).append("!important;color:").append(FG[t]).append("!important}");
        sb.append("body{margin:0!important;padding:3% 4%!important;line-height:1.65!important;overflow-wrap:anywhere}");
        sb.append("img,svg,video{max-width:100%!important;height:auto!important}");
        if (t != 0) {
            sb.append("body *{color:inherit!important;background-color:transparent!important}");
        }
        return sb.toString();
    }

    private WebResourceResponse blocked() {
        return new WebResourceResponse("text/plain", "utf-8", 403, "Blocked", new HashMap<String, String>(),
                new ByteArrayInputStream(new byte[0]));
    }

    private WebResourceResponse serve(Uri u) {
        try {
            String sc = u.getScheme();
            if ("data".equals(sc) || "about".equals(sc)) return null; // trang do app tự tạo
            EpubBook b = book;
            OfficeDoc o = office;
            if ((b == null && o == null) || !HOST.equals(u.getHost())) return blocked();
            String path = u.getPath();
            if (path == null) return blocked();
            if (path.startsWith("/")) path = path.substring(1);
            byte[] data = b != null ? b.read(path) : OfficeDoc.readEntry(o.zip, path);
            if (data == null) {
                return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found", new HashMap<String, String>(),
                        new ByteArrayInputStream(new byte[0]));
            }
            String mime = mimeOf(path);
            if (mime.equals("text/html") && b != null) {
                String html = new String(data, StandardCharsets.UTF_8);
                String style = "<style>" + css() + "</style>";
                int idx = html.toLowerCase(Locale.ROOT).indexOf("</head>");
                html = idx >= 0 ? html.substring(0, idx) + style + html.substring(idx) : style + html;
                data = html.getBytes(StandardCharsets.UTF_8);
            }
            return new WebResourceResponse(mime, "utf-8", new ByteArrayInputStream(data));
        } catch (Exception e) {
            return blocked();
        }
    }

    private static String mimeOf(String path) {
        String p = path.toLowerCase(Locale.ROOT);
        if (p.endsWith(".xhtml") || p.endsWith(".html") || p.endsWith(".htm") || p.endsWith(".xml")) return "text/html";
        if (p.endsWith(".css")) return "text/css";
        if (p.endsWith(".jpg") || p.endsWith(".jpeg")) return "image/jpeg";
        if (p.endsWith(".png")) return "image/png";
        if (p.endsWith(".gif")) return "image/gif";
        if (p.endsWith(".webp")) return "image/webp";
        if (p.endsWith(".svg")) return "image/svg+xml";
        if (p.endsWith(".ttf")) return "font/ttf";
        if (p.endsWith(".otf")) return "font/otf";
        if (p.endsWith(".woff")) return "font/woff";
        if (p.endsWith(".woff2")) return "font/woff2";
        return "application/octet-stream";
    }

    /** Link bên trong sách -> chuyển chương; link ra ngoài -> chặn (đọc offline). */
    private boolean navigate(Uri u) {
        if (!HOST.equals(u.getHost()) || mode == MODE_OFFICE) return true;
        if (book != null && u.getPath() != null) {
            String p = u.getPath().startsWith("/") ? u.getPath().substring(1) : u.getPath();
            int idx = book.spine.indexOf(p);
            if (idx >= 0) {
                chapter = idx;
                updateLabel();
            }
        }
        return false;
    }

    // ---------------------------------------------------------------- EPUB

    private void openEpub(File f) throws Exception {
        book = EpubBook.open(f);
        if (book.spine.isEmpty()) throw new Exception("EPUB không có nội dung");
        mode = MODE_EPUB;
        setChrome();
        titleView.setText(book.title.isEmpty() ? prettyName(f.getName()) : book.title);
        ensureWeb();
        int ch = Math.max(0, Math.min(prefs.getInt("ch_" + key(f), 0), book.spine.size() - 1));
        loadChapter(ch, prefs.getInt("sc_" + key(f), 0));
    }

    private void loadChapter(int i, int scroll) {
        if (book == null) return;
        chapter = Math.max(0, Math.min(i, book.spine.size() - 1));
        pendingScroll = scroll;
        web.loadUrl("https://" + HOST + "/" + Uri.encode(book.spine.get(chapter), "/"));
        updateLabel();
    }

    private void updateLabel() {
        if (mode == MODE_EPUB && book != null) {
            pageLabel.setText((chapter + 1) + "/" + book.spine.size() + " · " + book.titleOf(chapter));
        } else if (mode == MODE_OFFICE && office != null) {
            pageLabel.setText((section + 1) + "/" + office.count() + " · " + office.sectionTitle(section));
        }
    }

    private void showToc() {
        if (mode == MODE_OFFICE) {
            showOfficeToc();
            return;
        }
        if (book == null) return;
        final String[] items = new String[book.spine.size()];
        for (int i = 0; i < items.length; i++) items[i] = book.titleOf(i);
        new AlertDialog.Builder(this)
                .setTitle("Mục lục")
                .setItems(items, (d, w) -> loadChapter(w, 0))
                .show();
    }

    // ---------------------------------------------------------------- Office (DOCX / XLSX / PPTX)

    private void openOffice(File f, String kind) throws Exception {
        office = OfficeDoc.open(f, kind);
        mode = MODE_OFFICE;
        setChrome();
        titleView.setText(prettyName(f.getName()));
        ensureWeb();
        int sec = Math.max(0, Math.min(prefs.getInt("ch_" + key(f), 0), office.count() - 1));
        loadSection(sec, prefs.getInt("sc_" + key(f), 0));
    }

    private void loadSection(int i, final int scroll) {
        final OfficeDoc d = office;
        if (d == null) return;
        section = Math.max(0, Math.min(i, d.count() - 1));
        final int sec = section;
        final int token = ++loadToken;
        updateLabel();
        final String css = css();
        new Thread(() -> {
            String html;
            try {
                synchronized (d) {
                    html = d.html(sec, css);
                }
            } catch (Throwable e) {
                StackTraceElement[] st = e.getStackTrace();
                html = OfficeDoc.page(css, "<p>Không đọc được phần này: " + OfficeDoc.esc(e.getClass().getSimpleName() + ": " + e.getMessage()
                        + (st.length > 0 ? " @ " + st[0].getFileName() + ":" + st[0].getLineNumber() : "")) + "</p>");
            }
            final String h = html;
            runOnUiThread(() -> {
                if (token != loadToken || office != d || web == null) return;
                pendingScroll = scroll;
                web.loadDataWithBaseURL("https://" + HOST + "/", h, "text/html", "utf-8", null);
            });
        }).start();
    }

    private void showOfficeToc() {
        final OfficeDoc d = office;
        if (d == null) return;
        String[] items = new String[d.count()];
        for (int i = 0; i < items.length; i++) items[i] = d.sectionTitle(i);
        new AlertDialog.Builder(this)
                .setTitle("Chọn phần")
                .setItems(items, (dl, w) -> loadSection(w, 0))
                .show();
    }

    // ---------------------------------------------------------------- TXT

    private void openTxt(File f) throws Exception {
        byte[] data;
        try (FileInputStream in = new FileInputStream(f)) {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[32768];
            int n;
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
            data = bo.toByteArray();
        }
        String text = decodeText(data);
        int bad = 0, lim = Math.min(text.length(), 3000);
        for (int i = 0; i < lim; i++) {
            char c = text.charAt(i);
            if (c < 32 && c != '\n' && c != '\r' && c != '\t' || c == 0xFFFD) bad++;
        }
        if (lim > 0 && bad * 20 > lim) throw new Exception("Đây không phải file văn bản (định dạng không được hỗ trợ)");
        txtEscaped = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
        mode = MODE_TXT;
        setChrome();
        titleView.setText(prettyName(f.getName()));
        ensureWeb();
        pendingScroll = prefs.getInt("sc_" + key(f), 0);
        renderTxt();
    }

    private void renderTxt() {
        if (txtEscaped == null) return;
        String html = "<html><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
                + "<style>" + css() + "</style></head><body><div style=\"white-space:pre-wrap\">"
                + txtEscaped + "</div></body></html>";
        web.loadDataWithBaseURL("https://" + HOST + "/", html, "text/html", "utf-8", null);
    }

    private static String decodeText(byte[] b) {
        try {
            if (b.length >= 2 && (b[0] & 0xFF) == 0xFF && (b[1] & 0xFF) == 0xFE)
                return new String(b, 2, b.length - 2, "UTF-16LE");
            if (b.length >= 2 && (b[0] & 0xFF) == 0xFE && (b[1] & 0xFF) == 0xFF)
                return new String(b, 2, b.length - 2, "UTF-16BE");
            int off = (b.length >= 3 && (b[0] & 0xFF) == 0xEF && (b[1] & 0xFF) == 0xBB && (b[2] & 0xFF) == 0xBF) ? 3 : 0;
            try {
                return StandardCharsets.UTF_8.newDecoder()
                        .onMalformedInput(CodingErrorAction.REPORT)
                        .onUnmappableCharacter(CodingErrorAction.REPORT)
                        .decode(ByteBuffer.wrap(b, off, b.length - off)).toString();
            } catch (CharacterCodingException e) {
                // File tiếng Việt cũ thường là Windows-1258
                return new String(b, Charset.forName("windows-1258"));
            }
        } catch (Exception e) {
            return new String(b, StandardCharsets.ISO_8859_1);
        }
    }

    // ---------------------------------------------------------------- PDF

    private void openPdf(File f) throws Exception {
        pdfFd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY);
        pdf = new PdfRenderer(pdfFd);
        mode = MODE_PDF;
        setChrome();
        titleView.setText(prettyName(f.getName()));

        final int width = getResources().getDisplayMetrics().widthPixels;
        int cacheBytes = (int) Math.max(8L << 20, Runtime.getRuntime().maxMemory() / 6);
        pdfCache = new LruCache<Integer, Bitmap>(cacheBytes) {
            @Override
            protected int sizeOf(Integer k, Bitmap v) {
                return v.getByteCount();
            }
        };

        pdfList = new ListView(this);
        pdfList.setBackgroundColor(Color.parseColor("#777777"));
        pdfList.setDividerHeight(dp(6));
        pdfList.setAdapter(new BaseAdapter() {
            @Override public int getCount() { return pdf == null ? 0 : pdf.getPageCount(); }
            @Override public Object getItem(int i) { return i; }
            @Override public long getItemId(int i) { return i; }

            @Override
            public View getView(int pos, View convert, ViewGroup parent) {
                ImageView iv = convert instanceof ImageView ? (ImageView) convert : new ImageView(MainActivity.this);
                iv.setScaleType(ImageView.ScaleType.FIT_XY);
                Bitmap bmp = pdfCache == null ? null : pdfCache.get(pos);
                if (bmp == null) {
                    bmp = renderPage(pos, width);
                    if (pdfCache != null) pdfCache.put(pos, bmp);
                }
                iv.setImageBitmap(bmp);
                iv.setLayoutParams(new AbsListView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, bmp.getHeight()));
                return iv;
            }
        });
        pdfList.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override public void onScrollStateChanged(AbsListView v, int s) { }

            @Override
            public void onScroll(AbsListView v, int first, int visible, int total) {
                updateLabelPdf();
            }
        });
        content.removeAllViews();
        content.addView(pdfList, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        pdfList.setSelection(Math.min(prefs.getInt("pg_" + key(f), 0), pdf.getPageCount() - 1));
        updateLabelPdf();
    }

    private void updateLabelPdf() {
        if (mode == MODE_PDF && pdf != null && pdfList != null) {
            pageLabel.setText("Trang " + (pdfList.getFirstVisiblePosition() + 1) + " / " + pdf.getPageCount());
        }
    }

    private Bitmap renderPage(int index, int width) {
        try {
            PdfRenderer r = pdf;
            if (r == null) throw new IllegalStateException();
            synchronized (r) {
                PdfRenderer.Page page = r.openPage(index);
                try {
                    int h = Math.max(1, (int) ((long) width * page.getHeight() / Math.max(1, page.getWidth())));
                    Bitmap bmp = Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888);
                    bmp.eraseColor(Color.WHITE);
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                    return bmp;
                } finally {
                    page.close();
                }
            }
        } catch (Exception e) {
            Bitmap bmp = Bitmap.createBitmap(width, dp(120), Bitmap.Config.ARGB_8888);
            bmp.eraseColor(Color.WHITE);
            return bmp;
        }
    }

    // ---------------------------------------------------------------- nút điều khiển

    private void goRelative(int d) {
        if (mode == MODE_OFFICE && office != null) {
            int n = section + d;
            if (n >= 0 && n < office.count()) loadSection(n, 0);
        } else if (mode == MODE_EPUB && book != null) {
            int n = chapter + d;
            if (n >= 0 && n < book.spine.size()) loadChapter(n, 0);
        } else if (mode == MODE_PDF && pdfList != null) {
            int n = Math.max(0, Math.min(pdfList.getFirstVisiblePosition() + d, pdf.getPageCount() - 1));
            pdfList.setSelection(n);
        }
    }

    private void changeZoom(int delta) {
        if (web == null) return;
        int z = Math.max(60, Math.min(260, prefs.getInt("zoom", 110) + delta));
        prefs.edit().putInt("zoom", z).apply();
        web.getSettings().setTextZoom(z);
    }

    private void cycleTheme() {
        prefs.edit().putInt("theme", (theme() + 1) % 3).apply();
        if (web == null) return;
        web.setBackgroundColor(Color.parseColor(BG[theme()]));
        pendingScroll = web.getScrollY();
        if (mode == MODE_EPUB) loadChapter(chapter, pendingScroll);
        else if (mode == MODE_TXT) renderTxt();
        else if (mode == MODE_OFFICE) loadSection(section, pendingScroll);
    }

    // ---------------------------------------------------------------- chia sẻ ứng dụng

    /** Gửi chính file APK của ứng dụng qua Zalo / Bluetooth / Quick Share... */
    private void shareApp() {
        new Thread(() -> {
            try {
                File out = ApkProvider.apkFile(this);
                out.getParentFile().mkdirs();
                try (InputStream in = new FileInputStream(getApplicationInfo().sourceDir)) {
                    copy(in, out);
                }
                runOnUiThread(() -> {
                    Uri uri = Uri.parse("content://" + getPackageName() + ".apk/" + ApkProvider.FILE_NAME);
                    Intent s = new Intent(Intent.ACTION_SEND);
                    s.setType("application/vnd.android.package-archive");
                    s.putExtra(Intent.EXTRA_STREAM, uri);
                    s.putExtra(Intent.EXTRA_TEXT, "Ứng dụng Đọc Tài Liệu (PDF, Word, Excel, PowerPoint, EPUB, TXT) - không quảng cáo, đọc offline. Cài file này để dùng.");
                    s.setClipData(ClipData.newRawUri("apk", uri));
                    s.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(s, "Chia sẻ ứng dụng"));
                });
            } catch (Exception e) {
                runOnUiThread(() -> toast("Không chia sẻ được: " + e.getMessage()));
            }
        }).start();
    }
}
