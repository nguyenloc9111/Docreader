package vn.docreader;

import android.net.Uri;
import android.text.TextUtils;
import android.util.Xml;

import org.xmlpull.v1.XmlPullParser;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Bộ đọc EPUB tối giản: đọc container.xml -> OPF -> spine + mục lục (NCX hoặc nav). */
class EpubBook {
    final ZipFile zip;
    String title = "";
    final List<String> spine = new ArrayList<>();
    final Map<String, String> titles = new HashMap<>();

    private EpubBook(ZipFile z) { zip = z; }

    static EpubBook open(File f) throws Exception {
        EpubBook b = new EpubBook(new ZipFile(f));
        try {
            b.parse();
        } catch (Exception e) {
            b.close();
            throw e;
        }
        return b;
    }

    void close() {
        try { zip.close(); } catch (Exception ignored) { }
    }

    String titleOf(int i) {
        String t = titles.get(spine.get(i));
        return (t == null || t.isEmpty()) ? "Phần " + (i + 1) : t;
    }

    byte[] read(String path) throws Exception {
        ZipEntry e = zip.getEntry(path);
        if (e == null) return null;
        try (InputStream in = zip.getInputStream(e)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[16384];
            int n;
            while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            return out.toByteArray();
        }
    }

    private void parse() throws Exception {
        ZipEntry ce = zip.getEntry("META-INF/container.xml");
        if (ce == null) throw new Exception("Không phải file EPUB hợp lệ");
        String opf = null;
        try (InputStream in = zip.getInputStream(ce)) {
            XmlPullParser p = Xml.newPullParser();
            p.setInput(in, null);
            for (int e = p.getEventType(); e != XmlPullParser.END_DOCUMENT; e = p.next()) {
                if (e == XmlPullParser.START_TAG && p.getName().equals("rootfile")) {
                    opf = p.getAttributeValue(null, "full-path");
                    break;
                }
            }
        }
        if (opf == null) throw new Exception("Không tìm thấy file OPF");
        String opfDir = dirOf(opf);

        Map<String, String[]> manifest = new HashMap<>(); // id -> {path, mediaType, properties}
        List<String> idrefs = new ArrayList<>();
        String tocId = null;
        ZipEntry oe = zip.getEntry(opf);
        if (oe == null) throw new Exception("Thiếu file OPF");
        try (InputStream in = zip.getInputStream(oe)) {
            XmlPullParser p = Xml.newPullParser();
            p.setInput(in, null);
            for (int e = p.getEventType(); e != XmlPullParser.END_DOCUMENT; e = p.next()) {
                if (e != XmlPullParser.START_TAG) continue;
                String n = p.getName();
                if (n.equals("item")) {
                    String id = p.getAttributeValue(null, "id");
                    String href = p.getAttributeValue(null, "href");
                    if (id != null && href != null) {
                        manifest.put(id, new String[]{
                                resolve(opfDir, href),
                                p.getAttributeValue(null, "media-type"),
                                p.getAttributeValue(null, "properties")});
                    }
                } else if (n.equals("spine")) {
                    tocId = p.getAttributeValue(null, "toc");
                } else if (n.equals("itemref")) {
                    String r = p.getAttributeValue(null, "idref");
                    if (r != null) idrefs.add(r);
                } else if ((n.equals("dc:title") || n.equals("title")) && title.isEmpty()) {
                    title = p.nextText().trim();
                }
            }
        }
        for (String id : idrefs) {
            String[] m = manifest.get(id);
            if (m != null && (m[1] == null || m[1].contains("html"))) spine.add(m[0]);
        }

        // Mục lục (không bắt buộc, lỗi thì bỏ qua)
        try {
            String ncx = null, nav = null;
            if (tocId != null && manifest.get(tocId) != null) ncx = manifest.get(tocId)[0];
            for (String[] m : manifest.values()) {
                if (ncx == null && m[1] != null && m[1].contains("dtbncx")) ncx = m[0];
                if (nav == null && m[2] != null && (" " + m[2] + " ").contains(" nav ")) nav = m[0];
            }
            if (ncx != null) parseNcx(ncx);
            if (nav != null) parseNav(nav);
        } catch (Exception ignored) { }
    }

    private void parseNcx(String path) throws Exception {
        ZipEntry e0 = zip.getEntry(path);
        if (e0 == null) return;
        String dir = dirOf(path);
        try (InputStream in = zip.getInputStream(e0)) {
            XmlPullParser p = Xml.newPullParser();
            p.setInput(in, null);
            String label = null;
            for (int e = p.getEventType(); e != XmlPullParser.END_DOCUMENT; e = p.next()) {
                if (e != XmlPullParser.START_TAG) continue;
                String n = p.getName();
                if (n.equals("text")) {
                    label = p.nextText().replaceAll("\\s+", " ").trim();
                } else if (n.equals("content") && label != null) {
                    String src = p.getAttributeValue(null, "src");
                    if (src != null && !titles.containsKey(resolve(dir, src))) {
                        titles.put(resolve(dir, src), label);
                    }
                    label = null;
                }
            }
        }
    }

    private void parseNav(String path) throws Exception {
        ZipEntry e0 = zip.getEntry(path);
        if (e0 == null) return;
        String dir = dirOf(path);
        try (InputStream in = zip.getInputStream(e0)) {
            XmlPullParser p = Xml.newPullParser();
            p.setInput(in, null);
            for (int e = p.getEventType(); e != XmlPullParser.END_DOCUMENT; e = p.next()) {
                if (e == XmlPullParser.START_TAG && p.getName().equals("a")) {
                    String href = p.getAttributeValue(null, "href");
                    String text = textUntilEnd(p);
                    if (href != null && !text.isEmpty() && !titles.containsKey(resolve(dir, href))) {
                        titles.put(resolve(dir, href), text);
                    }
                }
            }
        }
    }

    private static String textUntilEnd(XmlPullParser p) throws Exception {
        StringBuilder sb = new StringBuilder();
        int depth = 1;
        while (depth > 0) {
            int e = p.next();
            if (e == XmlPullParser.START_TAG) depth++;
            else if (e == XmlPullParser.END_TAG) depth--;
            else if (e == XmlPullParser.TEXT) sb.append(p.getText());
            else if (e == XmlPullParser.END_DOCUMENT) break;
        }
        return sb.toString().replaceAll("\\s+", " ").trim();
    }

    static String dirOf(String path) {
        int i = path.lastIndexOf('/');
        return i < 0 ? "" : path.substring(0, i + 1);
    }

    static String resolve(String base, String href) {
        int h = href.indexOf('#');
        if (h >= 0) href = href.substring(0, h);
        int q = href.indexOf('?');
        if (q >= 0) href = href.substring(0, q);
        href = Uri.decode(href);
        String full = href.startsWith("/") ? href.substring(1) : base + href;
        ArrayList<String> out = new ArrayList<>();
        for (String s : full.split("/")) {
            if (s.isEmpty() || s.equals(".")) continue;
            if (s.equals("..")) {
                if (!out.isEmpty()) out.remove(out.size() - 1);
            } else {
                out.add(s);
            }
        }
        return TextUtils.join("/", out);
    }
}
