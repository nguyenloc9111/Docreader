# Đọc Tài Liệu (Android)

Đọc **PDF, Word (.docx), Excel (.xlsx), PowerPoint (.pptx), EPUB, TXT** hoàn toàn offline, không quảng cáo, không thu phí.

- Màn hình chính: ô tìm kiếm, lọc theo loại, tab Gần đây / Thiết bị / Dấu trang (bấm ☆).
- Cấp quyền "truy cập tất cả file" để app tự tìm tài liệu trong máy.
- Nhấn vào file/link tài liệu → chọn "Đọc Tài Liệu" → tự mở.
- Chưa hỗ trợ file Office cũ (.doc, .xls, .ppt).
- Menu ⋮ → "Chia sẻ ứng dụng" gửi APK cho máy khác.

Tạo APK: tải thư mục lên GitHub → Actions → Build APK → Run workflow.
