# Đọc Sách Offline (Android)

Đọc **EPUB, PDF, TXT** hoàn toàn offline. Không cần thư viện ngoài.

- Nhấn vào file hoặc link `.epub` / `.pdf` / `.txt` → chọn "Đọc Sách Offline" → tự mở.
- Sách được lưu vào thư viện trong app, nhớ trang/chương đang đọc.
- EPUB: mục lục, đổi cỡ chữ (A− / A+), đổi nền sáng / vàng / tối (◐).
- TXT: tự nhận UTF-8, UTF-16, Windows-1258 (tiếng Việt cũ).
- Menu ⋮ → "Chia sẻ ứng dụng" gửi file APK qua Zalo / Bluetooth / Quick Share cho máy khác.

## Tạo file APK

**Cách 1 – không cần máy tính (GitHub Actions)**
1. Tạo repo GitHub, tải toàn bộ thư mục này lên.
2. Vào tab Actions → "Build APK" → Run workflow.
3. Xong, tải `DocReader-APK` ở mục Artifacts, giải nén ra `app-debug.apk`.

**Cách 2 – Android Studio**
Mở thư mục này → Build → Build APK(s). File ở `app/build/outputs/apk/debug/`.

**Cách 3 – dòng lệnh** (cần JDK 17 + Android SDK, Gradle 8.7+):
`gradle assembleDebug`

## Cài trên máy khác
Nhận file APK → mở → cho phép "Cài ứng dụng không rõ nguồn" nếu máy hỏi.
